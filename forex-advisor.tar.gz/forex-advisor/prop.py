"""
Monitor de regras de prop firm — sem ligação à corretora.

O equity é introduzido à mão (ou por outro serviço via API). A partir dele o
módulo calcula quanto falta para cada limite, avisa por Telegram antes de uma
violação e diz qual o lote máximo que respeita as regras para um dado stop.

Modelo das regras (o das prop firms mais comuns; confirma sempre as da tua):
- Perda diária: o equity não pode descer mais de X% do SALDO INICIAL abaixo
  do equity com que o dia começou. O dia muda à hora e fuso configurados.
- Perda máxima estática: o equity nunca abaixo de saldo_inicial × (1 − Y%).
- Perda máxima trailing: o piso sobe com o pico de equity (pico − Y% do saldo
  inicial) e fica travado no saldo inicial quando lá chega.
"""

from __future__ import annotations

import json
import math
import threading
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import motor

# Tamanho de 1 lote. Os CFDs de metais variam de corretora para corretora —
# confirma a especificação do contrato na tua.
TAMANHO_CONTRATO = {"XAU": 100, "XAG": 5000}
TAMANHO_FX = 100_000
LOTE_MINIMO = 0.01

REGRAS_PADRAO = {
    "saldo_inicial": 10_000.0,
    "moeda": "USD",
    "perda_diaria_pct": 5.0,
    "perda_maxima_pct": 10.0,
    "tipo_perda_maxima": "estatica",   # "estatica" | "trailing"
    "objetivo_pct": 10.0,
    "risco_trade_pct": 1.0,
    "dias_minimos": 4,
    "aviso_pct": 70.0,                 # avisa quando X% de um limite foi consumido
    "fuso": "Europe/Prague",           # reset diário (muitas firms usam CE(S)T)
    "hora_reset": 0,
}

MOEDAS_CONTA = ("USD", "EUR", "GBP")


def _validar_regras(r: dict) -> dict:
    regras = {**REGRAS_PADRAO, **{k: v for k, v in r.items() if k in REGRAS_PADRAO}}
    if not regras["saldo_inicial"] > 0:
        raise ValueError("O saldo inicial tem de ser maior que zero.")
    if regras["moeda"] not in MOEDAS_CONTA:
        raise ValueError(f"Moeda da conta tem de ser uma de {', '.join(MOEDAS_CONTA)}.")
    for chave, maximo in (("perda_diaria_pct", 50), ("perda_maxima_pct", 50),
                          ("objetivo_pct", 100), ("risco_trade_pct", 10)):
        if not 0 < float(regras[chave]) <= maximo:
            raise ValueError(f"{chave} tem de estar entre 0 e {maximo}.")
    if regras["perda_diaria_pct"] > regras["perda_maxima_pct"]:
        raise ValueError("A perda diária não pode ser maior que a perda máxima.")
    if regras["tipo_perda_maxima"] not in ("estatica", "trailing"):
        raise ValueError("tipo_perda_maxima tem de ser 'estatica' ou 'trailing'.")
    if not 0 < float(regras["aviso_pct"]) < 100:
        raise ValueError("aviso_pct tem de estar entre 0 e 100.")
    if not 0 <= int(regras["hora_reset"]) <= 23:
        raise ValueError("hora_reset tem de estar entre 0 e 23.")
    if not 0 <= int(regras["dias_minimos"]) <= 60:
        raise ValueError("dias_minimos tem de estar entre 0 e 60.")
    try:
        ZoneInfo(regras["fuso"])
    except (ZoneInfoNotFoundError, ValueError):
        raise ValueError(f"Fuso horário desconhecido: {regras['fuso']}")
    for chave in ("saldo_inicial", "perda_diaria_pct", "perda_maxima_pct",
                  "objetivo_pct", "risco_trade_pct", "aviso_pct"):
        regras[chave] = float(regras[chave])
    regras["hora_reset"] = int(regras["hora_reset"])
    regras["dias_minimos"] = int(regras["dias_minimos"])
    return regras


class MonitorProp:
    def __init__(self, ficheiro: Path | None = None) -> None:
        self.ficheiro = ficheiro or (motor.DIR_DADOS / "prop.json")
        self._lock = threading.Lock()
        self._d: dict = self._ler()

    # ---------- persistência ----------
    def _ler(self) -> dict:
        try:
            if self.ficheiro.is_file():
                return json.loads(self.ficheiro.read_text(encoding="utf-8"))
        except Exception:
            motor.log.exception("Não foi possível ler o estado da conta prop")
        return {}

    def _gravar(self) -> None:
        try:
            self.ficheiro.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.ficheiro.with_suffix(".tmp")
            tmp.write_text(json.dumps(self._d, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self.ficheiro)
        except Exception:
            motor.log.exception("Não foi possível gravar o estado da conta prop")

    # ---------- tempo ----------
    def _dia_de_trading(self, agora: datetime | None = None) -> str:
        """Data do 'dia de trading' — muda à hora_reset no fuso da firm."""
        r = self._d["regras"]
        agora = agora or datetime.now(ZoneInfo(r["fuso"]))
        agora = agora.astimezone(ZoneInfo(r["fuso"]))
        return (agora - timedelta(hours=r["hora_reset"])).date().isoformat()

    def _rodar_dia(self, agora: datetime | None = None) -> None:
        hoje = self._dia_de_trading(agora)
        if self._d["inicio_dia"]["data"] != hoje:
            # O dia novo começa com o último equity conhecido.
            self._d["inicio_dia"] = {"data": hoje, "equity": self._d["equity"]}
            self._d["notificados"] = {}

    # ---------- operações ----------
    def configurar(self, regras: dict, nova_avaliacao: bool = False,
                   agora: datetime | None = None) -> dict:
        regras = _validar_regras(regras)
        with self._lock:
            if nova_avaliacao or not self._d:
                s = regras["saldo_inicial"]
                self._d = {"regras": regras, "equity": s, "pico": s,
                           "inicio_dia": {"data": "", "equity": s},
                           "dias_operados": [], "historico": [], "notificados": {},
                           "iniciada": datetime.now().isoformat(timespec="seconds")}
            else:
                self._d["regras"] = regras
            self._rodar_dia(agora)
            self._gravar()
        return self.estado(agora)

    def registar_equity(self, equity: float, operou: bool = True,
                        agora: datetime | None = None) -> dict:
        if not (equity >= 0 and math.isfinite(equity)):
            raise ValueError("Equity inválido.")
        with self._lock:
            if not self._d:
                raise ValueError("Configura primeiro as regras da conta.")
            self._rodar_dia(agora)
            self._d["equity"] = float(equity)
            self._d["pico"] = max(self._d["pico"], float(equity))
            hoje = self._d["inicio_dia"]["data"]
            if operou and hoje not in self._d["dias_operados"]:
                self._d["dias_operados"].append(hoje)
            self._d["historico"].append({
                "momento": datetime.now().isoformat(timespec="seconds"),
                "equity": float(equity)})
            self._d["historico"] = self._d["historico"][-500:]
            e = self._calcular()
            mensagens = self._novas_notificacoes(e)
            self._gravar()
        for m in mensagens:
            motor.notificar_telegram(m)
        e["notificacoes"] = mensagens
        return e

    def estado(self, agora: datetime | None = None) -> dict:
        with self._lock:
            if not self._d:
                return {"configurado": False, "regras_padrao": REGRAS_PADRAO}
            self._rodar_dia(agora)
            return self._calcular()

    # ---------- cálculo ----------
    def _calcular(self) -> dict:
        r, d = self._d["regras"], self._d
        s, eq = r["saldo_inicial"], d["equity"]

        limite_dia = s * r["perda_diaria_pct"] / 100
        piso_dia = d["inicio_dia"]["equity"] - limite_dia
        perda_dia = max(0.0, d["inicio_dia"]["equity"] - eq)

        limite_max = s * r["perda_maxima_pct"] / 100
        if r["tipo_perda_maxima"] == "trailing":
            piso_max = min(d["pico"] - limite_max, s)
        else:
            piso_max = s - limite_max
        # Quanto do limite máximo já foi consumido, medido a partir do topo do intervalo.
        consumo_max = max(0.0, (piso_max + limite_max) - eq)

        margem_dia = max(0.0, eq - piso_dia)
        margem_max = max(0.0, eq - piso_max)

        def nivel(consumido: float, limite: float, margem: float) -> str:
            if margem <= 0:
                return "violado"
            return "aviso" if consumido >= limite * r["aviso_pct"] / 100 else "ok"

        n_dia = nivel(perda_dia, limite_dia, margem_dia)
        n_max = nivel(consumo_max, limite_max, margem_max)
        ordem = {"ok": 0, "aviso": 1, "violado": 2}
        geral = max(n_dia, n_max, key=ordem.get)

        objetivo = s * r["objetivo_pct"] / 100
        lucro = eq - s
        dias = len(d["dias_operados"])
        risco_trade = s * r["risco_trade_pct"] / 100
        risco_permitido = 0.0 if geral == "violado" else min(risco_trade, margem_dia, margem_max)

        return {
            "configurado": True,
            "regras": r,
            "equity": round(eq, 2),
            "pico": round(d["pico"], 2),
            "dia": d["inicio_dia"]["data"],
            "equity_inicio_dia": round(d["inicio_dia"]["equity"], 2),
            "diario": {"limite": round(limite_dia, 2), "perda": round(perda_dia, 2),
                       "piso": round(piso_dia, 2), "margem": round(margem_dia, 2),
                       "usado_pct": round(min(100, perda_dia / limite_dia * 100), 1),
                       "nivel": n_dia},
            "maximo": {"limite": round(limite_max, 2), "consumido": round(consumo_max, 2),
                       "piso": round(piso_max, 2), "margem": round(margem_max, 2),
                       "usado_pct": round(min(100, consumo_max / limite_max * 100), 1),
                       "nivel": n_max, "tipo": r["tipo_perda_maxima"]},
            "objetivo": {"valor": round(objetivo, 2), "lucro": round(lucro, 2),
                         "progresso_pct": round(max(0.0, min(100, lucro / objetivo * 100)), 1),
                         "atingido": lucro >= objetivo},
            "dias": {"operados": dias, "minimos": r["dias_minimos"],
                     "em_falta": max(0, r["dias_minimos"] - dias)},
            "aprovada": lucro >= objetivo and dias >= r["dias_minimos"] and geral != "violado",
            "nivel": geral,
            "risco_permitido": round(risco_permitido, 2),
        }

    def _novas_notificacoes(self, e: dict) -> list[str]:
        """Uma mensagem por limite e por nível, no máximo uma vez por dia."""
        ja = self._d.setdefault("notificados", {})
        moeda = self._d["regras"]["moeda"]
        msgs = []
        for chave, nome in (("diario", "perda diária"), ("maximo", "perda máxima")):
            bloco = e[chave]
            if bloco["nivel"] == "ok":
                continue
            marca = f"{chave}:{bloco['nivel']}"
            if marca in ja:
                continue
            ja[marca] = True
            if bloco["nivel"] == "violado":
                msgs.append(f"⛔ Conta prop: limite de {nome} ULTRAPASSADO.\n"
                            f"Equity {e['equity']:.2f} {moeda} · piso {bloco['piso']:.2f}.\n"
                            "Não abras mais posições.")
            else:
                msgs.append(f"⚠️ Conta prop: {bloco['usado_pct']:.0f}% do limite de {nome} usado.\n"
                            f"Margem restante: {bloco['margem']:.2f} {moeda}.")
        if e["objetivo"]["atingido"] and "objetivo" not in ja:
            ja["objetivo"] = True
            falta = e["dias"]["em_falta"]
            msgs.append("🎯 Conta prop: objetivo de lucro atingido."
                        + (f" Faltam {falta} dia(s) de trading." if falta else
                           " Dias mínimos cumpridos."))
        return msgs


# ──────────────────────────────────────────────────────────────────────
# Cálculo de lote
# ──────────────────────────────────────────────────────────────────────

def _taxa(de: str, para: str) -> float:
    """Quantas unidades de `para` vale 1 unidade de `de`."""
    if de == para:
        return 1.0
    direto, inverso = f"{de}{para}=X", f"{para}{de}=X"
    precos = motor.mercado.precos_atuais([direto, inverso])
    if precos.get(direto):
        return precos[direto]
    if precos.get(inverso):
        return 1.0 / precos[inverso]
    raise RuntimeError(f"Sem cotação para converter {de} em {para}.")


def valor_por_lote(par: str, distancia: float, moeda_conta: str) -> float:
    """Perda, na moeda da conta, de 1 lote se o preço andar `distancia`."""
    base, cotada = motor._moedas(par)
    tamanho = TAMANHO_CONTRATO.get(base, TAMANHO_FX)
    return distancia * tamanho * _taxa(cotada, moeda_conta)


def tamanho_posicao(monitor: MonitorProp, par: str, entrada: float, stop: float) -> dict:
    if par not in motor.PARES:
        raise ValueError("Par desconhecido.")
    if not (entrada > 0 and stop > 0) or entrada == stop:
        raise ValueError("Entrada e stop têm de ser preços válidos e diferentes.")
    e = monitor.estado()
    if not e["configurado"]:
        raise ValueError("Configura primeiro as regras da conta.")

    moeda = e["regras"]["moeda"]
    distancia = abs(entrada - stop)
    por_lote = valor_por_lote(par, distancia, moeda)
    risco = e["risco_permitido"]
    # O epsilon evita que 1.1000 − 1.0980 = 0.00199999… transforme 0.50 em 0.49.
    passos = math.floor(risco / por_lote / LOTE_MINIMO + 1e-9) if por_lote > 0 else 0
    lotes = passos * LOTE_MINIMO
    lotes = round(lotes, 2)

    if e["nivel"] == "violado":
        motivo = "Limite ultrapassado — não abrir posições."
    elif lotes < LOTE_MINIMO:
        motivo = f"Stop demasiado largo para o risco disponível ({risco:.2f} {moeda})."
        lotes = 0.0
    else:
        motivo = None

    casas = motor._casas(par)
    pip = 0.01 if "JPY" in par else (0.1 if par.startswith(("XAU", "XAG")) else 0.0001)
    return {
        "par": par, "entrada": round(entrada, casas), "stop": round(stop, casas),
        "distancia_pips": round(distancia / pip, 1),
        "perda_por_lote": round(por_lote, 2),
        "risco_disponivel": risco,
        "lotes": lotes,
        "perda_se_stop": round(lotes * por_lote, 2),
        "moeda": moeda,
        "limitado_por": _limitador(e),
        "motivo": motivo,
        "nota": "Confirma o tamanho do contrato e o custo de spread/comissão na tua corretora.",
    }


def _limitador(e: dict) -> str:
    r = e["regras"]
    candidatos = {
        "risco por trade": r["saldo_inicial"] * r["risco_trade_pct"] / 100,
        "margem diária": e["diario"]["margem"],
        "margem máxima": e["maximo"]["margem"],
    }
    return min(candidatos, key=candidatos.get)


monitor = MonitorProp()
