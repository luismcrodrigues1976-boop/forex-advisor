"""Testa o monitor de regras de prop firm. Não toca na rede."""
import os
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
from zoneinfo import ZoneInfo

os.environ.setdefault("FOREX_DATA_DIR", tempfile.mkdtemp(prefix="forex-teste-"))
os.environ["ANTHROPIC_API_KEY"] = "teste"

from fastapi.testclient import TestClient  # noqa: E402

import app as api_app  # noqa: E402
import motor  # noqa: E402
import prop  # noqa: E402

PRAGA = ZoneInfo("Europe/Prague")
REGRAS = {"saldo_inicial": 10_000, "moeda": "USD", "perda_diaria_pct": 5,
          "perda_maxima_pct": 10, "tipo_perda_maxima": "estatica", "objetivo_pct": 10,
          "risco_trade_pct": 1, "dias_minimos": 4, "aviso_pct": 70,
          "fuso": "Europe/Prague", "hora_reset": 0}


def em(dia, hora=12):
    return datetime(2026, 10, dia, hora, 0, tzinfo=PRAGA)


class TesteRegras(unittest.TestCase):
    def setUp(self):
        self.ficheiro = Path(tempfile.mkdtemp()) / "prop.json"
        self.m = prop.MonitorProp(self.ficheiro)
        self.telegram = patch.object(motor, "notificar_telegram", return_value=True).start()
        self.addCleanup(patch.stopall)

    def configurar(self, **extra):
        return self.m.configurar({**REGRAS, **extra}, nova_avaliacao=True, agora=em(1))

    def test_sem_configuracao(self):
        self.assertFalse(self.m.estado()["configurado"])
        with self.assertRaises(ValueError):
            self.m.registar_equity(9_900)

    def test_estado_inicial(self):
        e = self.configurar()
        self.assertEqual(e["nivel"], "ok")
        self.assertEqual(e["diario"]["piso"], 9_500)
        self.assertEqual(e["maximo"]["piso"], 9_000)
        self.assertEqual(e["risco_permitido"], 100)  # 1% de 10k

    def test_perda_diaria_aviso_e_violacao(self):
        self.configurar()
        e = self.m.registar_equity(9_640, agora=em(1, 14))  # perdeu 360 de 500 = 72%
        self.assertEqual(e["diario"]["nivel"], "aviso")
        self.assertEqual(e["diario"]["margem"], 140)
        self.assertEqual(e["risco_permitido"], 100)
        e = self.m.registar_equity(9_450, agora=em(1, 15))
        self.assertEqual(e["diario"]["nivel"], "violado")
        self.assertEqual(e["nivel"], "violado")
        self.assertEqual(e["risco_permitido"], 0)

    def test_margem_diaria_limita_o_risco(self):
        self.configurar()
        e = self.m.registar_equity(9_560, agora=em(1, 14))  # faltam 60 para o piso
        self.assertEqual(e["risco_permitido"], 60)

    def test_dia_novo_parte_do_ultimo_equity(self):
        self.configurar()
        self.m.registar_equity(9_700, agora=em(1, 22))
        # 00:30 em Praga já é outro dia de trading
        e = self.m.registar_equity(9_650, agora=em(2, 0).replace(minute=30))
        self.assertEqual(e["equity_inicio_dia"], 9_700)
        self.assertEqual(e["diario"]["piso"], 9_200)
        self.assertEqual(e["diario"]["nivel"], "ok")

    def test_hora_de_reset_personalizada(self):
        # Reset às 23h: as 22h ainda contam como o mesmo dia de trading.
        self.configurar(hora_reset=23)
        self.m.registar_equity(9_800, agora=em(1, 22))
        e = self.m.registar_equity(9_790, agora=em(1, 22).replace(minute=50))
        self.assertEqual(e["equity_inicio_dia"], 10_000)

    def test_perda_maxima_estatica(self):
        self.configurar()
        for dia, eq in ((1, 9_600), (2, 9_300), (3, 9_020)):
            e = self.m.registar_equity(eq, agora=em(dia))
        self.assertEqual(e["maximo"]["nivel"], "aviso")
        self.assertEqual(e["maximo"]["margem"], 20)
        self.assertEqual(e["risco_permitido"], 20)

    def test_perda_maxima_trailing_sobe_e_trava(self):
        self.configurar(tipo_perda_maxima="trailing")
        e = self.m.registar_equity(10_500, agora=em(1))
        self.assertEqual(e["maximo"]["piso"], 9_500)
        e = self.m.registar_equity(11_500, agora=em(2))
        self.assertEqual(e["maximo"]["piso"], 10_000)  # travado no saldo inicial
        e = self.m.registar_equity(10_000, agora=em(3))
        self.assertEqual(e["maximo"]["nivel"], "violado")

    def test_objetivo_e_dias_minimos(self):
        self.configurar()
        for dia, eq in ((1, 10_300), (2, 10_700), (3, 11_050)):
            e = self.m.registar_equity(eq, agora=em(dia))
        self.assertTrue(e["objetivo"]["atingido"])
        self.assertEqual(e["dias"]["em_falta"], 1)
        self.assertFalse(e["aprovada"])
        e = self.m.registar_equity(11_060, agora=em(4))
        self.assertTrue(e["aprovada"])

    def test_atualizacao_sem_operar_nao_conta_dia(self):
        self.configurar()
        e = self.m.registar_equity(10_000, operou=False, agora=em(1))
        self.assertEqual(e["dias"]["operados"], 0)

    def test_telegram_uma_vez_por_nivel_e_dia(self):
        self.configurar()
        self.m.registar_equity(9_640, agora=em(1, 13))
        self.m.registar_equity(9_630, agora=em(1, 14))
        self.assertEqual(self.telegram.call_count, 1)
        self.m.registar_equity(9_450, agora=em(1, 15))  # agora viola
        self.assertEqual(self.telegram.call_count, 2)
        self.assertIn("ULTRAPASSADO", self.telegram.call_args[0][0])

    def test_persistencia(self):
        self.configurar()
        self.m.registar_equity(9_800, agora=em(1))
        outro = prop.MonitorProp(self.ficheiro)
        self.assertEqual(outro.estado(agora=em(1))["equity"], 9_800)

    def test_regras_invalidas(self):
        for mau in ({"perda_diaria_pct": 12}, {"moeda": "BTC"}, {"fuso": "Lua/Base"},
                    {"tipo_perda_maxima": "outro"}, {"saldo_inicial": 0}):
            with self.assertRaises(ValueError, msg=mau):
                self.configurar(**mau)

    def test_alterar_regras_mantem_equity(self):
        self.configurar()
        self.m.registar_equity(9_900, agora=em(1))
        e = self.m.configurar({**REGRAS, "risco_trade_pct": 0.5}, agora=em(1))
        self.assertEqual(e["equity"], 9_900)
        self.assertEqual(e["risco_permitido"], 50)


class TesteLote(unittest.TestCase):
    def setUp(self):
        self.m = prop.MonitorProp(Path(tempfile.mkdtemp()) / "prop.json")
        self.m.configurar(REGRAS, nova_avaliacao=True)
        taxas = {("USD", "USD"): 1.0, ("JPY", "USD"): 1 / 150, ("GBP", "USD"): 1.25}
        patch.object(prop, "_taxa", side_effect=lambda de, para: taxas[(de, para)]).start()
        self.addCleanup(patch.stopall)

    def test_eurusd(self):
        # 20 pips × 10 USD/pip = 200 por lote; risco 100 → 0.50 lotes
        r = prop.tamanho_posicao(self.m, "EUR/USD", 1.1000, 1.0980)
        self.assertEqual(r["distancia_pips"], 20)
        self.assertEqual(r["perda_por_lote"], 200)
        self.assertEqual(r["lotes"], 0.5)
        self.assertLessEqual(r["perda_se_stop"], r["risco_disponivel"])

    def test_usdjpy_converte_para_a_moeda_da_conta(self):
        # 30 pips em JPY: 0.30 × 100k = 30 000 JPY = 200 USD por lote
        r = prop.tamanho_posicao(self.m, "USD/JPY", 150.00, 150.30)
        self.assertAlmostEqual(r["perda_por_lote"], 200, places=2)
        self.assertEqual(r["lotes"], 0.5)

    def test_ouro_usa_contrato_de_100_oncas(self):
        # 5 USD × 100 oz = 500 por lote → 0.20 lotes
        r = prop.tamanho_posicao(self.m, "XAU/USD (Ouro)", 2400, 2395)
        self.assertEqual(r["lotes"], 0.2)

    def test_arredonda_para_baixo(self):
        r = prop.tamanho_posicao(self.m, "EUR/USD", 1.1000, 1.0967)  # 33 pips
        self.assertEqual(r["lotes"], 0.3)  # 0.303 → 0.30, nunca 0.31

    def test_stop_largo_demais(self):
        r = prop.tamanho_posicao(self.m, "EUR/USD", 1.1000, 0.9000)
        self.assertEqual(r["lotes"], 0)
        self.assertIsNotNone(r["motivo"])

    def test_conta_violada_da_zero(self):
        self.m.registar_equity(8_900)
        r = prop.tamanho_posicao(self.m, "EUR/USD", 1.1000, 1.0980)
        self.assertEqual(r["lotes"], 0)
        self.assertIn("ultrapassado", r["motivo"])

    def test_entradas_invalidas(self):
        with self.assertRaises(ValueError):
            prop.tamanho_posicao(self.m, "XPTO/USD", 1, 0.9)
        with self.assertRaises(ValueError):
            prop.tamanho_posicao(self.m, "EUR/USD", 1.1, 1.1)


class TesteRotas(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cliente = TestClient(api_app.app)

    def setUp(self):
        prop.monitor = prop.MonitorProp(Path(tempfile.mkdtemp()) / "prop.json")
        patch.object(motor, "notificar_telegram", return_value=False).start()
        patch.object(prop, "_taxa", return_value=1.0).start()
        self.addCleanup(patch.stopall)

    def test_fluxo_completo(self):
        self.assertFalse(self.cliente.get("/api/conta").json()["configurado"])
        r = self.cliente.put("/api/conta/regras", json={**REGRAS, "nova_avaliacao": True})
        self.assertEqual(r.status_code, 200)
        r = self.cliente.post("/api/conta/equity", json={"equity": 9_700})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["diario"]["perda"], 300)
        r = self.cliente.post("/api/conta/lote",
                              json={"par": "EUR/USD", "entrada": 1.1, "stop": 1.098})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["lotes"], 0.5)

    def test_regras_invalidas_dao_400(self):
        r = self.cliente.put("/api/conta/regras", json={**REGRAS, "fuso": "Nada/Nenhum"})
        self.assertEqual(r.status_code, 400)

    def test_equity_antes_de_configurar_da_400(self):
        r = self.cliente.post("/api/conta/equity", json={"equity": 9_000})
        self.assertEqual(r.status_code, 400)

    def test_lote_nao_conta_para_o_limite_da_ia(self):
        self.cliente.put("/api/conta/regras", json={**REGRAS, "nova_avaliacao": True})
        api_app._registos.clear()
        for _ in range(3):
            self.cliente.post("/api/conta/lote",
                              json={"par": "EUR/USD", "entrada": 1.1, "stop": 1.098})
        self.assertEqual(sum(len(v) for v in api_app._registos.values()), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
