"""
Modo automático: scan contínuo dos melhores candidatos.

Em cada ciclo corre `motor.melhor()` (só indicadores, não gasta tokens), fica
com os candidatos acima dos limiares e notifica os novos por Telegram. Com
`confirmar_ia` ligado, cada candidato novo passa primeiro pelo sinal completo
do Claude — só é notificado se a IA concordar com a direção — com um teto de
chamadas por hora independente do limite por IP da interface.

Nada aqui abre posições. É um radar, não um executor.
"""

from __future__ import annotations

import json
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

import motor
import prop

CONFIG_PADRAO = {
    "ativo": False,
    "intervalo_min": 5,          # minutos entre scans
    "forca_minima": 2.0,         # 2.0 = Moderado, 3.0 = Forte
    "concordancia_minima": 75,   # % de timeframes alinhados
    "confirmar_ia": False,       # pede o sinal completo ao Claude antes de notificar
    "max_ia_hora": 6,            # teto de confirmações pela IA por hora
    "arrefecimento_h": 4,        # não repete o mesmo par+direção durante X horas
}

LIMITES = {
    "intervalo_min": (2, 120),
    "forca_minima": (0.5, 6.0),
    "concordancia_minima": (50, 100),
    "max_ia_hora": (0, 30),
    "arrefecimento_h": (0.5, 48),
}

DIRECAO_IA = {"COMPRA": "COMPRAR", "VENDA": "VENDER"}


def mercado_aberto(agora: datetime | None = None) -> bool:
    """Forex fecha de sexta ~21h UTC a domingo ~21h UTC."""
    agora = (agora or datetime.now(timezone.utc)).astimezone(timezone.utc)
    dia, hora = agora.weekday(), agora.hour  # segunda = 0
    if dia == 5:
        return False
    if dia == 4 and hora >= 21:
        return False
    if dia == 6 and hora < 21:
        return False
    return True


def _validar(config: dict) -> dict:
    c = {**CONFIG_PADRAO, **{k: v for k, v in config.items() if k in CONFIG_PADRAO}}
    c["ativo"] = bool(c["ativo"])
    c["confirmar_ia"] = bool(c["confirmar_ia"])
    for chave, (minimo, maximo) in LIMITES.items():
        valor = float(c[chave])
        if not minimo <= valor <= maximo:
            raise ValueError(f"{chave} tem de estar entre {minimo} e {maximo}.")
        c[chave] = int(valor) if chave in ("intervalo_min", "concordancia_minima",
                                           "max_ia_hora") else valor
    return c


class ScannerAuto:
    def __init__(self, ficheiro: Path | None = None) -> None:
        self.ficheiro = ficheiro or (motor.DIR_DADOS / "auto.json")
        self._lock = threading.Lock()
        self._a_correr = threading.Lock()   # impede dois ciclos em simultâneo
        guardado = self._ler()
        self.config = _validar(guardado.get("config", {}))
        self.disparos: list[dict] = guardado.get("disparos", [])[-50:]
        self._ultimos: dict[str, float] = guardado.get("ultimos", {})
        self._ia_usos: list[float] = []
        self.candidatos: list[dict] = []
        self.ultima_execucao: str | None = None
        self.proxima: float = time.time() if self.config["ativo"] else 0.0
        self.situacao = "Desligado" if not self.config["ativo"] else "A aguardar o primeiro scan"
        self.ciclos = 0

    # ---------- persistência ----------
    def _ler(self) -> dict:
        try:
            if self.ficheiro.is_file():
                return json.loads(self.ficheiro.read_text(encoding="utf-8"))
        except Exception:
            motor.log.exception("Não foi possível ler o estado do modo automático")
        return {}

    def _gravar(self) -> None:
        try:
            self.ficheiro.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.ficheiro.with_suffix(".tmp")
            tmp.write_text(json.dumps({"config": self.config, "disparos": self.disparos,
                                       "ultimos": self._ultimos},
                                      ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self.ficheiro)
        except Exception:
            motor.log.exception("Não foi possível gravar o estado do modo automático")

    # ---------- configuração ----------
    def configurar(self, alteracoes: dict) -> dict:
        with self._lock:
            estava = self.config["ativo"]
            self.config = _validar({**self.config, **alteracoes})
            if self.config["ativo"] and not estava:
                self.proxima = time.time()          # corre já ao ligar
                self.situacao = "A aguardar o primeiro scan"
            elif self.config["ativo"]:
                # Intervalo alterado: reagenda a partir do último scan.
                self.proxima = min(self.proxima or time.time(),
                                   time.time() + self.config["intervalo_min"] * 60)
            else:
                self.proxima = 0.0
                self.situacao = "Desligado"
            self._gravar()
        return self.estado()

    def estado(self) -> dict:
        with self._lock:
            return {
                "config": dict(self.config),
                "situacao": self.situacao,
                "mercado_aberto": mercado_aberto(),
                "ultima_execucao": self.ultima_execucao,
                "proxima": (datetime.fromtimestamp(self.proxima).isoformat(timespec="seconds")
                            if self.config["ativo"] and self.proxima else None),
                "ciclos": self.ciclos,
                "candidatos": list(self.candidatos),
                "disparos": list(reversed(self.disparos[-20:])),
                "ia_usadas_hora": self._ia_na_ultima_hora(),
            }

    # ---------- ciclo ----------
    def devido(self) -> bool:
        return self.config["ativo"] and time.time() >= self.proxima

    def _ia_na_ultima_hora(self) -> int:
        agora = time.time()
        self._ia_usos = [t for t in self._ia_usos if agora - t < 3600]
        return len(self._ia_usos)

    def _em_arrefecimento(self, chave: str) -> bool:
        ultimo = self._ultimos.get(chave)
        return bool(ultimo) and time.time() - ultimo < self.config["arrefecimento_h"] * 3600

    def ciclo(self, agora: datetime | None = None) -> list[dict]:
        """Um scan. Devolve os disparos novos. Seguro para chamar a qualquer momento."""
        if not self._a_correr.acquire(blocking=False):
            return []
        try:
            return self._ciclo(agora)
        finally:
            self._a_correr.release()

    def _ciclo(self, agora: datetime | None) -> list[dict]:
        c = self.config
        with self._lock:
            self.proxima = time.time() + c["intervalo_min"] * 60
        if not mercado_aberto(agora):
            with self._lock:
                self.situacao = "Mercado fechado — em pausa até domingo à noite"
                self.candidatos = []
            return []

        try:
            ranking = motor.melhor()["ranking"]
        except RuntimeError as exc:
            with self._lock:
                self.situacao = f"Erro no scan: {exc}"
            return []

        qualificados = [
            x for x in ranking
            if x["forca"] >= c["forca_minima"]
            and x["concordancia"] >= c["concordancia_minima"]
            and not x["parado"]
        ]
        conta = prop.monitor.estado()
        conta_violada = conta.get("configurado") and conta.get("nivel") == "violado"

        novos: list[dict] = []
        for cand in qualificados:
            chave = f"{cand['par']}|{cand['direcao']}"
            if self._em_arrefecimento(chave):
                continue
            disparo = {
                "momento": datetime.now().isoformat(timespec="seconds"),
                "par": cand["par"], "direcao": cand["direcao"],
                "timeframe": cand["timeframe_ideal"], "forca": cand["forca"],
                "qualidade": cand["qualidade"], "concordancia": cand["concordancia"],
                "preco": cand["preco"], "estado": "notificado",
            }
            if c["confirmar_ia"]:
                if self._ia_na_ultima_hora() >= c["max_ia_hora"]:
                    disparo["estado"] = "sem confirmação (teto de IA/hora)"
                    # Não entra em arrefecimento: tenta-se outra vez quando houver quota.
                    novos.append(disparo)
                    continue
                self._confirmar_com_ia(disparo, conta)
            self._ultimos[chave] = time.time()
            if conta_violada and disparo["estado"] == "notificado":
                disparo["estado"] = "silenciado (conta prop violada)"
            novos.append(disparo)

        for d in novos:
            if d["estado"] == "notificado":
                motor.notificar_telegram(_mensagem(d))

        with self._lock:
            self.candidatos = qualificados[:8]
            self.ultima_execucao = datetime.now().isoformat(timespec="seconds")
            self.ciclos += 1
            self.situacao = (f"{len(qualificados)} candidato(s) acima dos limiares"
                             if qualificados else "Nenhum candidato acima dos limiares")
            if novos:
                self.disparos = (self.disparos + novos)[-50:]
            # Limpa arrefecimentos antigos para o ficheiro não crescer.
            limite = time.time() - 48 * 3600
            self._ultimos = {k: v for k, v in self._ultimos.items() if v > limite}
            self._gravar()
        for d in novos:
            motor.log.info("Auto: %s %s %s — %s", d["par"], d["direcao"], d["timeframe"], d["estado"])
        return novos

    def _confirmar_com_ia(self, disparo: dict, conta: dict) -> None:
        self._ia_usos.append(time.time())
        try:
            s = motor.sinal(disparo["par"], disparo["timeframe"])
        except Exception as exc:
            disparo["estado"] = f"erro na IA: {exc}"
            return
        ia = s.get("ia", {})
        disparo.update({"ia_sinal": ia.get("sinal"), "confianca": ia.get("confianca"),
                        "stop_loss": ia.get("stop_loss"), "take_profit": ia.get("take_profit"),
                        "rr": ia.get("rr"), "preco": s.get("preco", disparo["preco"])})
        if ia.get("sinal") != DIRECAO_IA[disparo["direcao"]]:
            disparo["estado"] = f"rejeitado pela IA ({ia.get('sinal')})"
            return
        if conta.get("configurado") and ia.get("stop_loss"):
            try:
                lote = prop.tamanho_posicao(prop.monitor, disparo["par"],
                                            disparo["preco"], ia["stop_loss"])
                disparo["lotes"] = lote["lotes"]
                disparo["moeda"] = lote["moeda"]
                disparo["perda_se_stop"] = lote["perda_se_stop"]
            except Exception as exc:
                motor.log.warning("Auto: lote não calculado: %s", exc)


def _mensagem(d: dict) -> str:
    seta = "🟢" if d["direcao"] == "COMPRA" else "🔴"
    linhas = [f"{seta} Candidato: {d['par']} {d['direcao']}",
              f"Timeframe: {d['timeframe']} · {d['qualidade']} (força {d['forca']}) · "
              f"{d['concordancia']}% alinhado",
              f"Preço: {d['preco']}"]
    if d.get("ia_sinal"):
        linhas.append(f"IA: {d['ia_sinal']} · confiança {d['confianca']}/100 · R:R {d.get('rr')}")
        linhas.append(f"SL {d['stop_loss']:.5f} · TP {d['take_profit']:.5f}")
    if d.get("lotes") is not None:
        linhas.append(f"Lote máx. (regras prop): {d['lotes']:.2f} · "
                      f"perda no stop {d['perda_se_stop']:.2f} {d['moeda']}")
    linhas.append("Não é aconselhamento financeiro.")
    return "\n".join(linhas)


scanner = ScannerAuto()
