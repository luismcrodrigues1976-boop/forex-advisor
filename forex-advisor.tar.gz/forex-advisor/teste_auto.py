"""Testa o modo automático. Não toca na rede: melhor(), sinal() e Telegram são duplos."""
import os
import tempfile
import time
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

os.environ.setdefault("FOREX_DATA_DIR", tempfile.mkdtemp(prefix="forex-teste-"))
os.environ["ANTHROPIC_API_KEY"] = "teste"

from fastapi.testclient import TestClient  # noqa: E402

import app as api_app  # noqa: E402
import auto  # noqa: E402
import motor  # noqa: E402
import prop  # noqa: E402

TERCA = datetime(2026, 9, 29, 12, tzinfo=timezone.utc)


def candidato(par="EUR/USD", direcao="COMPRA", forca=3.2, conc=100, parado=False, tf="1 hora"):
    return {"par": par, "direcao": direcao, "forca": forca, "qualidade": "Forte",
            "concordancia": conc, "timeframe_ideal": tf, "preco": 1.1,
            "parado": parado, "atr_pct": 0.1}


def ranking(*cands):
    return {"ranking": list(cands), "melhor": cands[0] if cands else None}


def sinal_ia(sinal="COMPRAR", sl=1.098, tp=1.104):
    return {"preco": 1.1, "ia": {"sinal": sinal, "confianca": 72, "stop_loss": sl,
                                 "take_profit": tp, "rr": 2.0}}


class TesteAuto(unittest.TestCase):
    def setUp(self):
        self.s = auto.ScannerAuto(Path(tempfile.mkdtemp()) / "auto.json")
        prop.monitor = prop.MonitorProp(Path(tempfile.mkdtemp()) / "prop.json")
        self.telegram = patch.object(motor, "notificar_telegram", return_value=True).start()
        self.addCleanup(patch.stopall)

    def correr(self, *cands, **kw):
        with patch.object(motor, "melhor", return_value=ranking(*cands)):
            return self.s.ciclo(agora=kw.get("agora", TERCA))

    def test_desligado_por_omissao(self):
        self.assertFalse(self.s.config["ativo"])
        self.assertFalse(self.s.devido())

    def test_ligar_agenda_scan_imediato(self):
        self.s.configurar({"ativo": True})
        self.assertTrue(self.s.devido())
        self.correr(candidato())
        self.assertFalse(self.s.devido())  # próximo só daqui a intervalo_min

    def test_filtra_pelos_limiares(self):
        novos = self.correr(candidato("EUR/USD"), candidato("GBP/USD", forca=1.5),
                            candidato("USD/JPY", conc=50), candidato("AUD/USD", parado=True))
        self.assertEqual([n["par"] for n in novos], ["EUR/USD"])
        self.assertEqual(self.telegram.call_count, 1)
        self.assertIn("EUR/USD COMPRA", self.telegram.call_args[0][0])

    def test_arrefecimento_evita_repeticao(self):
        self.correr(candidato())
        self.assertEqual(self.correr(candidato()), [])
        self.assertEqual(self.telegram.call_count, 1)

    def test_direcao_contraria_nao_esta_em_arrefecimento(self):
        self.correr(candidato(direcao="COMPRA"))
        novos = self.correr(candidato(direcao="VENDA"))
        self.assertEqual(len(novos), 1)

    def test_arrefecimento_expira(self):
        self.correr(candidato())
        self.s._ultimos["EUR/USD|COMPRA"] = time.time() - 5 * 3600
        self.assertEqual(len(self.correr(candidato())), 1)

    def test_fim_de_semana_nao_chama_o_mercado(self):
        sabado = datetime(2026, 10, 3, 12, tzinfo=timezone.utc)
        with patch.object(motor, "melhor") as falso:
            self.s.ciclo(agora=sabado)
        falso.assert_not_called()
        self.assertIn("fechado", self.s.estado()["situacao"])

    def test_horario_do_mercado(self):
        self.assertTrue(auto.mercado_aberto(TERCA))
        self.assertFalse(auto.mercado_aberto(datetime(2026, 10, 2, 21, 30, tzinfo=timezone.utc)))
        self.assertFalse(auto.mercado_aberto(datetime(2026, 10, 4, 20, tzinfo=timezone.utc)))
        self.assertTrue(auto.mercado_aberto(datetime(2026, 10, 4, 22, tzinfo=timezone.utc)))

    def test_sem_ia_nao_chama_o_modelo(self):
        with patch.object(motor, "sinal") as falso:
            self.correr(candidato())
        falso.assert_not_called()

    def test_ia_confirma_e_mensagem_traz_sl_tp(self):
        self.s.configurar({"confirmar_ia": True})
        with patch.object(motor, "sinal", return_value=sinal_ia()):
            novos = self.correr(candidato())
        self.assertEqual(novos[0]["estado"], "notificado")
        msg = self.telegram.call_args[0][0]
        self.assertIn("SL 1.09800", msg)
        self.assertIn("confiança 72", msg)

    def test_ia_discorda_nao_notifica(self):
        self.s.configurar({"confirmar_ia": True})
        with patch.object(motor, "sinal", return_value=sinal_ia("AGUARDAR")):
            novos = self.correr(candidato())
        self.assertIn("rejeitado", novos[0]["estado"])
        self.telegram.assert_not_called()

    def test_teto_de_ia_por_hora(self):
        self.s.configurar({"confirmar_ia": True, "max_ia_hora": 1})
        with patch.object(motor, "sinal", return_value=sinal_ia()) as falso:
            novos = self.correr(candidato("EUR/USD"), candidato("GBP/USD"))
        self.assertEqual(falso.call_count, 1)
        self.assertIn("teto", novos[1]["estado"])
        # O que ficou sem quota não entra em arrefecimento.
        self.assertNotIn("GBP/USD|COMPRA", self.s._ultimos)

    def test_lote_prop_na_notificacao(self):
        prop.monitor.configurar({"saldo_inicial": 10_000}, nova_avaliacao=True)
        self.s.configurar({"confirmar_ia": True})
        with patch.object(motor, "sinal", return_value=sinal_ia()), \
             patch.object(prop, "_taxa", return_value=1.0):
            novos = self.correr(candidato())
        self.assertEqual(novos[0]["lotes"], 0.5)
        self.assertIn("Lote máx.", self.telegram.call_args[0][0])

    def test_conta_violada_silencia(self):
        prop.monitor.configurar({"saldo_inicial": 10_000}, nova_avaliacao=True)
        prop.monitor.registar_equity(8_900)
        self.telegram.reset_mock()
        novos = self.correr(candidato())
        self.assertIn("silenciado", novos[0]["estado"])
        self.telegram.assert_not_called()

    def test_erro_no_mercado_nao_rebenta(self):
        with patch.object(motor, "melhor", side_effect=RuntimeError("Yahoo em baixo")):
            self.assertEqual(self.s.ciclo(agora=TERCA), [])
        self.assertIn("Yahoo em baixo", self.s.estado()["situacao"])

    def test_persistencia(self):
        self.s.configurar({"ativo": True, "intervalo_min": 10})
        self.correr(candidato())
        outro = auto.ScannerAuto(self.s.ficheiro)
        self.assertTrue(outro.config["ativo"])
        self.assertEqual(outro.config["intervalo_min"], 10)
        self.assertEqual(len(outro.disparos), 1)
        self.assertTrue(outro._em_arrefecimento("EUR/USD|COMPRA"))

    def test_config_invalida(self):
        for mau in ({"intervalo_min": 1}, {"forca_minima": 10}, {"concordancia_minima": 20}):
            with self.assertRaises(ValueError, msg=mau):
                self.s.configurar(mau)


class TesteRotasAuto(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cliente = TestClient(api_app.app)

    def setUp(self):
        auto.scanner = auto.ScannerAuto(Path(tempfile.mkdtemp()) / "auto.json")

    def test_ligar_e_desligar(self):
        r = self.cliente.put("/api/auto", json={"ativo": True})
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.json()["config"]["ativo"])
        self.assertIsNotNone(r.json()["proxima"])
        r = self.cliente.put("/api/auto", json={"ativo": False})
        self.assertFalse(r.json()["config"]["ativo"])
        self.assertIsNone(r.json()["proxima"])

    def test_alteracao_parcial_mantem_o_resto(self):
        self.cliente.put("/api/auto", json={"forca_minima": 3.0})
        r = self.cliente.put("/api/auto", json={"intervalo_min": 15})
        self.assertEqual(r.json()["config"]["forca_minima"], 3.0)

    def test_invalido_da_400(self):
        r = self.cliente.put("/api/auto", json={"intervalo_min": 0})
        self.assertEqual(r.status_code, 400)


if __name__ == "__main__":
    unittest.main(verbosity=2)
