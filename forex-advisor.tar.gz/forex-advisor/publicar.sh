#!/usr/bin/env bash
#
# Publica o Forex Advisor: GitHub + servidor + nginx, num só comando.
#
# Corre isto NO VPS (SSH), a partir da pasta do projeto:
#
#     bash publicar.sh                 # tudo
#     bash publicar.sh --so-servidor   # salta o GitHub
#     bash publicar.sh --so-github     # salta o deploy
#
# Antes: cria o repositório VAZIO em https://github.com/new
#        com o nome  forex-advisor  (sem README, sem .gitignore).
#
set -euo pipefail

REPO_UTILIZADOR="luismcrodrigues1976-boop"
REPO_NOME="forex-advisor"
SITE_NGINX="/etc/nginx/sites-available/otc-trade"
HTPASSWD="/etc/nginx/.htpasswd-advisor"
UTILIZADOR_WEB="luis"
DOMINIO="luis-otc.duckdns.org"

FAZER_GITHUB=1
FAZER_SERVIDOR=1
for arg in "$@"; do
  case "$arg" in
    --so-github)   FAZER_SERVIDOR=0 ;;
    --so-servidor) FAZER_GITHUB=0 ;;
    -h|--help)     sed -n '2,15p' "$0"; exit 0 ;;
    *) echo "Argumento desconhecido: $arg" >&2; exit 1 ;;
  esac
done

cd "$(dirname "${BASH_SOURCE[0]}")"

titulo() { printf '\n\033[1;36m==> %s\033[0m\n' "$1"; }
aviso()  { printf '\033[1;33m  ! %s\033[0m\n' "$1"; }

# ──────────────────────────────────────────────────────────────
# 1. GitHub
# ──────────────────────────────────────────────────────────────
if [[ $FAZER_GITHUB -eq 1 ]]; then
  titulo "GitHub"

  command -v git >/dev/null || { apt-get update -qq && apt-get install -y -qq git; }

  git config --global --get user.email >/dev/null 2>&1 || {
    read -rp "  Email para os commits: " email
    read -rp "  Nome para os commits: " nome
    git config --global user.email "$email"
    git config --global user.name  "$nome"
  }

  # Ficheiro que nunca pode ir para o repositório
  cat > .gitignore <<'EOF'
# Chaves e segredos — NUNCA versionar
.env
*.env
!exemplo.env
/etc/forex-advisor.env

# Python
__pycache__/
*.py[cod]
.venv/
venv/

# Dados em execução
alertas.json
app.log
*.log
*.bak-*
*.tmp

# Sistema
.DS_Store
EOF

  if [[ ! -d .git ]]; then
    git init -q
    git branch -M main
  fi

  # Remoto: SSH se houver chave, senão HTTPS
  if [[ -f ~/.ssh/id_ed25519 || -f ~/.ssh/id_rsa ]]; then
    URL_REMOTO="git@github.com:${REPO_UTILIZADOR}/${REPO_NOME}.git"
  else
    URL_REMOTO="https://github.com/${REPO_UTILIZADOR}/${REPO_NOME}.git"
    aviso "Sem chave SSH — o git vai pedir utilizador e Personal Access Token."
    aviso "Cria o token em: https://github.com/settings/tokens (scope: repo)"
  fi

  if git remote get-url origin >/dev/null 2>&1; then
    git remote set-url origin "$URL_REMOTO"
  else
    git remote add origin "$URL_REMOTO"
  fi
  echo "  origin: $URL_REMOTO"

  # Confirmação final de que nenhum segredo entra no commit
  git add -A
  if git diff --cached --name-only | grep -Eq '(^|/)\.env$|forex-advisor\.env'; then
    echo "ABORTADO: um ficheiro .env ia ser commitado." >&2
    exit 1
  fi

  if git diff --cached --quiet; then
    echo "  nada mudou desde o último commit"
  else
    git commit -q -m "Forex Advisor: API FastAPI, frontend e deploy no VPS"
    echo "  commit criado"
  fi

  echo "  a enviar para o GitHub..."
  if git push -u origin main; then
    echo "  https://github.com/${REPO_UTILIZADOR}/${REPO_NOME}"
  else
    aviso "O push falhou. Verifica que o repositório VAZIO existe em:"
    aviso "https://github.com/new  →  nome: ${REPO_NOME}"
    exit 1
  fi
fi

# ──────────────────────────────────────────────────────────────
# 2. Servidor
# ──────────────────────────────────────────────────────────────
if [[ $FAZER_SERVIDOR -eq 1 ]]; then
  [[ $EUID -eq 0 ]] || { echo "O deploy precisa de root." >&2; exit 1; }

  titulo "Aplicação"
  bash deploy/instalar.sh

  titulo "Palavra-passe de acesso"
  if [[ -f "$HTPASSWD" ]]; then
    echo "  $HTPASSWD já existe, mantido"
  else
    command -v htpasswd >/dev/null || apt-get install -y -qq apache2-utils
    echo "  Define a palavra-passe para o utilizador '$UTILIZADOR_WEB':"
    htpasswd -c "$HTPASSWD" "$UTILIZADOR_WEB"
    chown root:www-data "$HTPASSWD"
    chmod 640 "$HTPASSWD"
  fi

  titulo "nginx"
  python3 deploy/ligar_nginx.py --site "$SITE_NGINX" --snippet deploy/nginx-advisor.conf

  titulo "Verificação"
  sleep 2
  if curl -sf http://127.0.0.1:8100/api/saude >/dev/null; then
    echo "  API local OK"
  else
    aviso "A API não respondeu. journalctl -u forex-advisor -n 50 --no-pager"
  fi

  codigo=$(curl -s -o /dev/null -w '%{http_code}' "https://${DOMINIO}/advisor/" || echo "000")
  if [[ "$codigo" == "401" ]]; then
    echo "  https://${DOMINIO}/advisor/ responde 401 — a autenticação está ativa. Correto."
  elif [[ "$codigo" == "200" ]]; then
    aviso "Responde 200 SEM pedir palavra-passe. Confirma o auth_basic no nginx."
  else
    aviso "Resposta inesperada do domínio: HTTP $codigo"
  fi
fi

titulo "Feito"
cat <<FIM
  App:     https://${DOMINIO}/advisor/   (utilizador: ${UTILIZADOR_WEB})
  GitHub:  https://github.com/${REPO_UTILIZADOR}/${REPO_NOME}

  Se ainda não puseste as chaves:
    nano /etc/forex-advisor.env && systemctl restart forex-advisor

  Logs:
    journalctl -u forex-advisor -f
FIM
