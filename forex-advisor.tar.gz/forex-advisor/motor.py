"""
Motor do Forex Advisor — lógica partilhada, sem interface.

Reutiliza a mesma estratégia da versão desktop (RSI/EMA/ATR/MACD + pontuação),
mas devolve estruturas de dados em vez de texto formatado, para o frontend
web poder renderizar como quiser.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from logging.handlers import RotatingFileHandler
from pathlib import Path

import anthropic
import pandas as pd
import requests
import ta
import yfinance as yf

# ──────────────────────────────────────────────────────────────────────
# Configuração
# ──────────────────────────────────────────────────────────────────────

APP_NOME = "Forex Advisor"
DIR_DADOS = Path(os.getenv("FOREX_DATA_DIR", "/var/lib/forex-advisor"))
MODELO = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5")

log = logging.getLogger("forex")


def configurar_log() -> None:
    if log.handlers:
        return
    log.setLevel(logging.INFO)
    try:
        DIR_DADOS.mkdir(parents=True, exist_ok=True)
        handler: logging.Handler = RotatingFileHandler(
            DIR_DADOS / "app.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8"
        )
    except OSError:
        handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-7s | %(message)s"))
    log.addHandler(handler)


# ──────────────────────────────────────────────────────────────────────
# Prompts
# ──────────────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """
És um analista de Forex disciplinado. A tua função é decidir se há um setup
com vantagem clara AGORA, a partir dos dados que recebes, e não encontrar
sempre uma operação.

Regras de decisão:
1. AGUARDAR é a resposta por omissão. Só dás COMPRAR ou VENDER quando o
   timeframe pedido e pelo menos um timeframe superior apontam no mesmo
   sentido, ou quando há uma razão concreta e visível nas velas (rejeição de
   nível, rutura com fecho) que justifique ir contra.
2. O "score técnico fixo" vem de regras simples (RSI/EMA/MACD). Serve de
   referência; podes discordar dele, mas diz porquê.
3. Se houver evento de impacto ALTO nas moedas do par nas próximas horas,
   a resposta é AGUARDAR, salvo timeframe Diário/Semanal.
4. Volatilidade muito baixa (ATR no percentil < 20) → prefere AGUARDAR.
5. Stop loss entre 0,8 e 2,5 × ATR, atrás de estrutura (máximo/mínimo recente)
   quando fizer sentido. Take profit com risco/recompensa ≥ 1,5.
6. Usa só as notícias e eventos fornecidos. Não inventes factos, níveis nem eventos.
7. A confiança (0–100) deve ser calibrada: 50 = moeda ao ar. Acima de 75 só
   com confluência forte entre timeframes e contexto limpo.

Responde sempre através da ferramenta registar_sinal, em português europeu.
"""

FERRAMENTA_SINAL = {
    "name": "registar_sinal",
    "description": "Regista a decisão de trading estruturada para o par e timeframe analisados.",
    "input_schema": {
        "type": "object",
        "properties": {
            "sinal": {"type": "string", "enum": ["COMPRAR", "VENDER", "AGUARDAR"]},
            "confianca": {"type": "integer", "minimum": 0, "maximum": 100,
                          "description": "Probabilidade calibrada de o sinal estar certo, 0-100."},
            "stop_loss": {"type": "number", "description": "Preço do stop loss (0 se AGUARDAR)."},
            "take_profit": {"type": "number", "description": "Preço do take profit (0 se AGUARDAR)."},
            "invalidacao": {"type": "string", "description": "O que invalida a ideia, numa frase."},
            "analise_tecnica": {"type": "array", "items": {"type": "string"}, "maxItems": 5},
            "noticias": {"type": "string", "description": "Leitura das notícias/eventos fornecidos, ou 'Sem impacto relevante'."},
            "justificacao": {"type": "string", "description": "Motivo da decisão em 2-4 frases."},
            "riscos": {"type": "array", "items": {"type": "string"}, "maxItems": 3},
        },
        "required": ["sinal", "confianca", "stop_loss", "take_profit", "invalidacao",
                     "analise_tecnica", "noticias", "justificacao", "riscos"],
    },
}

# Regras duras aplicadas pelo código depois da resposta do modelo.
CONFIANCA_MINIMA = int(os.getenv("CONFIANCA_MINIMA", "60"))
RR_MINIMO = float(os.getenv("RR_MINIMO", "1.5"))
HORAS_BLOQUEIO_EVENTO = float(os.getenv("HORAS_BLOQUEIO_EVENTO", "2"))

SENTIMENTO_PROMPT = """
És um analista sénior de sentimento de mercado Forex.

Responde SEMPRE neste formato:

🌍 SENTIMENTO GERAL DO MERCADO: Risk-On / Risk-Off / Neutro

📊 FORÇA DAS MOEDAS (de mais forte para mais fraca):
1.
2.
3.
4.
5.

📰 PRINCIPAIS CATALISADORES:
- Lista os fatores mais importantes

🎯 VIÉS ATUAL:
- USD: Forte / Fraco / Neutro
- EUR: Forte / Fraco / Neutro
- GBP: Forte / Fraco / Neutro
- JPY: Forte / Fraco / Neutro
- AUD: Forte / Fraco / Neutro

💡 CONCLUSÃO:
- Resumo objetivo

⚠️ DISCLAIMER: Isto não é aconselhamento financeiro.
"""

# ──────────────────────────────────────────────────────────────────────
# Instrumentos
# ──────────────────────────────────────────────────────────────────────

PARES: dict[str, str] = {
    "EUR/USD": "EURUSD=X",
    "GBP/USD": "GBPUSD=X",
    "USD/JPY": "USDJPY=X",
    "USD/CHF": "USDCHF=X",
    "AUD/USD": "AUDUSD=X",
    "USD/CAD": "USDCAD=X",
    "NZD/USD": "NZDUSD=X",
    "EUR/GBP": "EURGBP=X",
    "EUR/JPY": "EURJPY=X",
    "GBP/JPY": "GBPJPY=X",
    "AUD/JPY": "AUDJPY=X",
    "XAU/USD (Ouro)": "GC=F",
    "XAG/USD (Prata)": "SI=F",
}

PARES_SENTIMENTO = ["EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD", "XAU/USD (Ouro)"]


@dataclass(frozen=True)
class Timeframe:
    intervalo: str
    periodo: str
    reamostrar: str | None = None


TIMEFRAMES: dict[str, Timeframe] = {
    "15 minutos": Timeframe("15m", "10d"),
    "1 hora": Timeframe("1h", "30d"),
    "4 horas": Timeframe("1h", "60d", reamostrar="4h"),
    "Diário": Timeframe("1d", "1y"),
    "Semanal": Timeframe("1wk", "2y"),
}

COLUNAS = ("Open", "High", "Low", "Close")

# ──────────────────────────────────────────────────────────────────────
# Dados de mercado
# ──────────────────────────────────────────────────────────────────────


class Mercado:
    """Downloads em lote com cache partilhada por todos os utilizadores."""

    TTL_PADRAO = 120

    def __init__(self) -> None:
        self._cache: dict[tuple[str, str, str], tuple[float, pd.DataFrame]] = {}
        self._lock = threading.Lock()

    def historico(
        self, tickers: list[str], periodo: str, intervalo: str, ttl: int | None = None
    ) -> dict[str, pd.DataFrame]:
        ttl = self.TTL_PADRAO if ttl is None else ttl
        agora = time.time()
        resultado: dict[str, pd.DataFrame] = {}
        em_falta: list[str] = []

        with self._lock:
            for t in tickers:
                item = self._cache.get((t, periodo, intervalo))
                if item and agora - item[0] < ttl:
                    resultado[t] = item[1]
                else:
                    em_falta.append(t)

        if em_falta:
            novos = self._descarregar(em_falta, periodo, intervalo)
            if novos:
                with self._lock:
                    for t, df in novos.items():
                        self._cache[(t, periodo, intervalo)] = (agora, df)
                resultado.update(novos)
        return resultado

    def _descarregar(self, tickers: list[str], periodo: str, intervalo: str) -> dict:
        try:
            bruto = yf.download(
                tickers, period=periodo, interval=intervalo, group_by="ticker",
                auto_adjust=False, actions=False, progress=False, threads=True,
            )
        except Exception:
            log.exception("Erro no download %s %s/%s", tickers, periodo, intervalo)
            return {}

        if bruto is None or bruto.empty:
            log.warning("Sem dados para %s (%s/%s)", tickers, periodo, intervalo)
            return {}

        saida: dict[str, pd.DataFrame] = {}
        if isinstance(bruto.columns, pd.MultiIndex):
            disponiveis = set(bruto.columns.get_level_values(0))
            for t in tickers:
                if t in disponiveis:
                    df = self._normalizar(bruto[t])
                    if df is not None:
                        saida[t] = df
        else:
            df = self._normalizar(bruto)
            if df is not None and tickers:
                saida[tickers[0]] = df
        return saida

    @staticmethod
    def _normalizar(df):
        if df is None or df.empty:
            return None
        df = df.copy()
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)
        if not all(c in df.columns for c in COLUNAS):
            return None
        df = df.dropna(subset=list(COLUNAS))
        return df if not df.empty else None

    def precos_atuais(self, tickers: list[str]) -> dict[str, float]:
        for periodo, intervalo, ttl in (("1d", "1m", 20), ("5d", "1h", 60)):
            dados = self.historico(tickers, periodo, intervalo, ttl=ttl)
            if dados:
                precos = {}
                for t, df in dados.items():
                    try:
                        precos[t] = float(df["Close"].iloc[-1])
                    except (IndexError, ValueError, TypeError):
                        continue
                if precos:
                    return precos
        return {}


def reamostrar(df: pd.DataFrame, regra: str) -> pd.DataFrame:
    agregacao = {"Open": "first", "High": "max", "Low": "min", "Close": "last"}
    if "Volume" in df.columns:
        agregacao["Volume"] = "sum"
    return df.resample(regra).agg(agregacao).dropna(subset=list(COLUNAS))


def calcular_indicadores(df, minimo: int = 40):
    if df is None or len(df) < minimo:
        return None
    df = df.copy()
    fecho, maximo, minimo_col = df["Close"], df["High"], df["Low"]

    df["RSI"] = ta.momentum.RSIIndicator(fecho, window=14).rsi()
    df["EMA9"] = ta.trend.EMAIndicator(fecho, window=9).ema_indicator()
    df["EMA21"] = ta.trend.EMAIndicator(fecho, window=21).ema_indicator()
    df["ATR"] = ta.volatility.AverageTrueRange(
        maximo, minimo_col, fecho, window=14
    ).average_true_range()

    macd = ta.trend.MACD(fecho)
    df["MACD"] = macd.macd()
    df["MACD_signal"] = macd.macd_signal()
    df["MACD_hist"] = macd.macd_diff()

    df = df.dropna(subset=["RSI", "EMA9", "EMA21", "ATR", "MACD_hist"])
    return df if not df.empty else None


def pontuar(rsi: float, ema9: float, ema21: float, macd_hist: float):
    """Pontuação idêntica à da versão desktop."""
    score = 0.0
    razoes: list[str] = []

    if rsi < 35:
        score += 2
        razoes.append("RSI baixo")
    elif rsi > 65:
        score -= 2
        razoes.append("RSI alto")

    if ema9 > ema21:
        score += 1.5
        razoes.append("EMA+")
    else:
        score -= 1.5
        razoes.append("EMA-")

    if macd_hist > 0:
        score += 1
        razoes.append("MACD+")
    else:
        score -= 1
        razoes.append("MACD-")

    if score >= 2.5:
        sinal = "COMPRA"
    elif score <= -2.5:
        sinal = "VENDA"
    else:
        sinal = "NEUTRO"
    return sinal, score, razoes


# ──────────────────────────────────────────────────────────────────────
# Serviços externos
# ──────────────────────────────────────────────────────────────────────


class Finnhub:
    BASE = "https://finnhub.io/api/v1"

    def __init__(self) -> None:
        self._sessao: requests.Session | None = None
        self._lock = threading.Lock()

    @property
    def chave(self) -> str:
        return os.getenv("FINNHUB_API_KEY", "").strip()

    def _get(self, caminho: str, params: dict, timeout: int = 10):
        with self._lock:
            if self._sessao is None:
                self._sessao = requests.Session()
                self._sessao.headers.update({"User-Agent": APP_NOME})
        resposta = self._sessao.get(
            f"{self.BASE}{caminho}", params={**params, "token": self.chave}, timeout=timeout
        )
        resposta.raise_for_status()
        return resposta.json()

    def noticias(self, limite: int = 8) -> list[str]:
        if not self.chave:
            return []
        try:
            dados = self._get("/news", {"category": "forex"}, timeout=8)
            if isinstance(dados, list):
                return [
                    item["headline"].strip()
                    for item in dados[:limite]
                    if item.get("headline")
                ]
        except Exception as exc:
            log.warning("Finnhub notícias: %s", exc)
        return []

    def calendario(self, dias: int = 7) -> list[dict]:
        hoje = datetime.now().date()
        dados = self._get(
            "/calendar/economic",
            {"from": str(hoje), "to": str(hoje + timedelta(days=dias))},
            timeout=12,
        )
        if isinstance(dados, dict):
            if dados.get("error"):
                raise RuntimeError(str(dados["error"]))
            return dados.get("economicCalendar") or []
        return []


class Claude:
    def __init__(self) -> None:
        self._cliente: anthropic.Anthropic | None = None
        self._lock = threading.Lock()

    def cliente(self) -> anthropic.Anthropic:
        chave = os.getenv("ANTHROPIC_API_KEY", "").strip()
        if not chave:
            raise RuntimeError("ANTHROPIC_API_KEY não configurada no servidor.")
        with self._lock:
            if self._cliente is None:
                self._cliente = anthropic.Anthropic(api_key=chave, timeout=60.0, max_retries=2)
        return self._cliente

    def perguntar(self, system: str, prompt: str, max_tokens: int = 1500) -> str:
        resposta = self.cliente().messages.create(
            model=MODELO, max_tokens=max_tokens, system=system,
            messages=[{"role": "user", "content": prompt}],
        )
        texto = "".join(
            b.text for b in resposta.content if getattr(b, "type", "") == "text"
        )
        return texto.strip() or "Sem resposta do modelo."

    def perguntar_estruturado(self, system: str, prompt: str, ferramenta: dict,
                              max_tokens: int = 1200) -> dict:
        """Obriga o modelo a responder pela ferramenta e devolve o JSON."""
        resposta = self.cliente().messages.create(
            model=MODELO, max_tokens=max_tokens, system=system,
            tools=[ferramenta],
            tool_choice={"type": "tool", "name": ferramenta["name"]},
            messages=[{"role": "user", "content": prompt}],
        )
        for bloco in resposta.content:
            if getattr(bloco, "type", "") == "tool_use":
                return dict(bloco.input)
        raise RuntimeError("O modelo não devolveu o sinal estruturado.")


# ──────────────────────────────────────────────────────────────────────
# Alertas
# ──────────────────────────────────────────────────────────────────────


class GestorAlertas:
    def __init__(self, ficheiro: Path | None = None) -> None:
        self.ficheiro = ficheiro or (DIR_DADOS / "alertas.json")
        self._lock = threading.Lock()
        self._proximo_id = 1
        self._alertas: list[dict] = self._ler()

    def _ler(self) -> list[dict]:
        try:
            if self.ficheiro.is_file():
                dados = json.loads(self.ficheiro.read_text(encoding="utf-8"))
                validos = [d for d in dados if isinstance(d, dict) and d.get("par") in PARES]
                if validos:
                    self._proximo_id = max(int(d.get("id", 0)) for d in validos) + 1
                return validos
        except Exception:
            log.exception("Não foi possível ler os alertas")
        return []

    def _gravar(self) -> None:
        try:
            self.ficheiro.parent.mkdir(parents=True, exist_ok=True)
            temporario = self.ficheiro.with_suffix(".tmp")
            temporario.write_text(
                json.dumps(self._alertas, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            temporario.replace(self.ficheiro)  # escrita atómica
        except Exception:
            log.exception("Não foi possível gravar os alertas")

    def adicionar(self, par: str, condicao: str, preco: float) -> dict:
        if par not in PARES:
            raise ValueError("Par desconhecido.")
        if condicao not in ("Acima de", "Abaixo de"):
            raise ValueError("Condição inválida.")
        if not (preco > 0):
            raise ValueError("Preço tem de ser maior que zero.")
        with self._lock:
            alerta = {
                "id": self._proximo_id,
                "par": par,
                "ticker": PARES[par],
                "condicao": condicao,
                "preco": float(preco),
                "ativo": True,
                "criado": datetime.now().isoformat(timespec="seconds"),
            }
            self._proximo_id += 1
            self._alertas.append(alerta)
            self._gravar()
            return dict(alerta)

    def remover(self, id_alerta: int) -> bool:
        with self._lock:
            antes = len(self._alertas)
            self._alertas = [a for a in self._alertas if a.get("id") != id_alerta]
            if len(self._alertas) != antes:
                self._gravar()
                return True
            return False

    def listar(self, apenas_ativos: bool = True) -> list[dict]:
        with self._lock:
            return [
                dict(a) for a in self._alertas if a.get("ativo") or not apenas_ativos
            ]

    def verificar(self, precos: dict[str, float]) -> list[dict]:
        disparados: list[dict] = []
        with self._lock:
            for alerta in self._alertas:
                if not alerta.get("ativo"):
                    continue
                atual = precos.get(alerta["ticker"])
                if atual is None:
                    continue
                acima = alerta["condicao"] == "Acima de" and atual >= alerta["preco"]
                abaixo = alerta["condicao"] == "Abaixo de" and atual <= alerta["preco"]
                if acima or abaixo:
                    alerta["ativo"] = False
                    alerta["disparado_em"] = datetime.now().isoformat(timespec="seconds")
                    alerta["preco_disparo"] = atual
                    disparados.append(dict(alerta))
            if disparados:
                self._gravar()
        return disparados


def notificar_telegram(mensagem: str) -> bool:
    """Envia para o Telegram se BOT_TOKEN e CHAT_ID estiverem definidos."""
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat:
        return False
    try:
        r = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat, "text": mensagem},
            timeout=10,
        )
        r.raise_for_status()
        return True
    except Exception as exc:
        log.warning("Telegram: %s", exc)
        return False


# ──────────────────────────────────────────────────────────────────────
# Operações de alto nível
# ──────────────────────────────────────────────────────────────────────

mercado = Mercado()
finnhub = Finnhub()
claude = Claude()
alertas = GestorAlertas()


def scan() -> dict:
    dados = mercado.historico(list(PARES.values()), "30d", "1h", ttl=120)
    if not dados:
        raise RuntimeError("Não foi possível obter cotações do Yahoo Finance.")

    linhas = []
    for nome, ticker in PARES.items():
        df = calcular_indicadores(dados.get(ticker))
        if df is None:
            continue
        u = df.iloc[-1]
        rsi, ema9, ema21 = float(u["RSI"]), float(u["EMA9"]), float(u["EMA21"])
        atr, hist = float(u["ATR"]), float(u["MACD_hist"])
        sinal, score, razoes = pontuar(rsi, ema9, ema21, hist)
        linhas.append({
            "par": nome,
            "sinal": sinal,
            "score": round(score, 1),
            "rsi": round(rsi, 1),
            "atr": round(atr, 5),
            "preco": round(float(u["Close"]), 5),
            "razoes": razoes,
        })

    linhas.sort(key=lambda x: x["score"], reverse=True)
    return {
        "momento": datetime.now().isoformat(timespec="seconds"),
        "total": len(linhas),
        "resultados": linhas,
    }


def _df_par(par: str, timeframe: str) -> pd.DataFrame:
    """DataFrame com indicadores para um par/timeframe (usa a cache do Mercado)."""
    if par not in PARES:
        raise ValueError("Par desconhecido.")
    if timeframe not in TIMEFRAMES:
        raise ValueError("Timeframe desconhecido.")

    tf = TIMEFRAMES[timeframe]
    ticker = PARES[par]
    dados = mercado.historico([ticker], tf.periodo, tf.intervalo, ttl=60)
    df = dados.get(ticker)
    if df is None:
        raise RuntimeError("Dados insuficientes para este par/timeframe.")
    if tf.reamostrar:
        df = reamostrar(df, tf.reamostrar)
    df = calcular_indicadores(df)
    if df is None:
        raise RuntimeError("Dados insuficientes para calcular indicadores.")
    return df


def indicadores_do_par(par: str, timeframe: str, df: pd.DataFrame | None = None) -> dict:
    if df is None:
        df = _df_par(par, timeframe)
    u = df.iloc[-1]
    atr = float(u["ATR"])
    return {
        "par": par,
        "timeframe": timeframe,
        "preco": float(u["Close"]),
        "rsi": float(u["RSI"]),
        "ema9": float(u["EMA9"]),
        "ema21": float(u["EMA21"]),
        "atr": atr,
        "macd": float(u["MACD"]),
        "macd_signal": float(u["MACD_signal"]),
        "macd_hist": float(u["MACD_hist"]),
        "stop_loss": atr,
        "take_profit": atr * 2,
        "velas": [
            {"t": str(i), "c": round(float(c), 5)}
            for i, c in df["Close"].tail(120).items()
        ],
    }


# ──────────────────────────────────────────────────────────────────────
# Contexto para o modelo
# ──────────────────────────────────────────────────────────────────────

PALAVRAS_MOEDA: dict[str, tuple[str, ...]] = {
    "USD": ("usd", "dollar", "fed ", "fomc", "powell", "treasury", "u.s.", "nonfarm", "payrolls"),
    "EUR": ("eur", "euro", "ecb", "lagarde", "eurozone", "germany", "german"),
    "GBP": ("gbp", "sterling", "pound", "boe", "bank of england", "uk ", "britain"),
    "JPY": ("jpy", "yen", "boj", "bank of japan", "japan"),
    "CHF": ("chf", "swiss", "franc", "snb"),
    "AUD": ("aud", "aussie", "rba", "australia"),
    "CAD": ("cad", "loonie", "bank of canada", "canada", "crude", "oil"),
    "NZD": ("nzd", "kiwi", "rbnz", "new zealand"),
    "XAU": ("gold", "xau", "bullion"),
    "XAG": ("silver", "xag"),
}

PAISES_MOEDA: dict[str, tuple[str, ...]] = {
    "USD": ("US",), "EUR": ("EU", "EA", "DE", "FR", "IT", "ES"), "GBP": ("GB", "UK"),
    "JPY": ("JP",), "CHF": ("CH",), "AUD": ("AU",), "CAD": ("CA",), "NZD": ("NZ",),
    "XAU": (), "XAG": (),
}


def _moedas(par: str) -> list[str]:
    base = par.split(" ")[0]  # "XAU/USD (Ouro)" -> "XAU/USD"
    return base.split("/")


def _casas(par: str) -> int:
    if par.startswith(("XAU", "XAG")):
        return 2
    return 3 if "JPY" in par else 5


def _noticias_do_par(moedas: list[str], limite: int = 5) -> list[str]:
    titulos = finnhub.noticias(limite=40)
    chaves = [p for m in moedas for p in PALAVRAS_MOEDA.get(m, ())]
    relevantes = [t for t in titulos if any(k in f" {t.lower()} " for k in chaves)]
    return relevantes[:limite]


def _eventos_proximos(moedas: list[str], horas: float = 24) -> list[dict] | None:
    """Eventos de impacto médio/alto nas moedas do par. None = calendário indisponível."""
    if not finnhub.chave:
        return None
    paises = {p for m in moedas for p in PAISES_MOEDA.get(m, ())}
    try:
        eventos = finnhub.calendario(dias=2)
    except Exception as exc:
        log.warning("Calendário para o sinal: %s", exc)
        return None
    agora = pd.Timestamp.now(tz="UTC")
    saida = []
    for ev in eventos:
        if str(ev.get("country", "")).upper() not in paises:
            continue
        impacto = str(ev.get("impact", "")).lower()
        nivel = "alto" if ("high" in impacto or impacto == "3") else (
            "medio" if ("medium" in impacto or impacto == "2") else "baixo")
        if nivel == "baixo":
            continue
        try:
            quando = pd.Timestamp(ev.get("time"))
            quando = quando.tz_localize("UTC") if quando.tzinfo is None else quando.tz_convert("UTC")
        except Exception:
            continue
        faltam = (quando - agora).total_seconds() / 3600
        if -1 <= faltam <= horas:
            saida.append({"evento": ev.get("event", ""), "pais": ev.get("country", ""),
                          "impacto": nivel, "horas": round(faltam, 1)})
    saida.sort(key=lambda e: e["horas"])
    return saida


def _confluencia_do_par(par: str) -> dict[str, dict]:
    saida = {}
    for tf in PESOS_CONFLUENCIA:
        try:
            dados = _scores_por_timeframe(tf).get(par)
        except Exception:
            dados = None
        if dados:
            saida[tf] = {"sinal": dados["sinal"], "score": dados["score"], "rsi": dados["rsi"]}
    return saida


def _montar_prompt(par: str, timeframe: str, df: pd.DataFrame, noticias: list[str],
                   eventos: list[dict] | None, mtf: dict[str, dict]) -> tuple[str, dict]:
    c = _casas(par)
    u = df.iloc[-1]
    preco, atr = float(u["Close"]), float(u["ATR"])
    sinal_det, score, razoes = pontuar(float(u["RSI"]), float(u["EMA9"]),
                                       float(u["EMA21"]), float(u["MACD_hist"]))

    ult = df.tail(20)
    max20, min20 = float(ult["High"].max()), float(ult["Low"].min())
    atr_pct_rank = float((df["ATR"].tail(100) < atr).mean() * 100)
    ema21_incl = (float(u["EMA21"]) - float(df["EMA21"].iloc[-6])) / atr if len(df) > 6 else 0.0

    velas = "\n".join(
        f"{str(i)[:16]} | {r.Open:.{c}f} {r.High:.{c}f} {r.Low:.{c}f} {r.Close:.{c}f}"
        f" | RSI {r.RSI:.0f} | MACDh {r.MACD_hist:+.{c}f}"
        for i, r in ult.iterrows()
    )
    txt_mtf = "\n".join(f"- {tf}: {d['sinal']} (score {d['score']:+.1f}, RSI {d['rsi']:.0f})"
                        for tf, d in mtf.items()) or "- Indisponível"
    if eventos is None:
        txt_eventos = "Calendário indisponível — trata como incerteza."
    elif not eventos:
        txt_eventos = "Nenhum evento de impacto médio/alto nas próximas 24 h."
    else:
        txt_eventos = "\n".join(
            f"- [{e['impacto'].upper()}] {e['pais']} {e['evento']} "
            f"({'há' if e['horas'] < 0 else 'daqui a'} {abs(e['horas']):.1f} h)" for e in eventos[:8])
    txt_noticias = "\n".join(f"- {t}" for t in noticias) or "Sem notícias específicas destas moedas."

    prompt = f"""PAR: {par} | TIMEFRAME: {timeframe} | PREÇO: {preco:.{c}f}

INDICADORES (última vela):
RSI14 {float(u['RSI']):.1f} | EMA9 {float(u['EMA9']):.{c}f} | EMA21 {float(u['EMA21']):.{c}f}
MACD {float(u['MACD']):+.{c}f} | Sinal {float(u['MACD_signal']):+.{c}f} | Hist {float(u['MACD_hist']):+.{c}f}
ATR14 {atr:.{c}f} (percentil {atr_pct_rank:.0f} das últimas 100 velas)
Inclinação da EMA21 nas últimas 5 velas: {ema21_incl:+.2f} × ATR

ESTRUTURA (20 velas):
Máximo {max20:.{c}f} ({(max20 - preco) / atr:+.1f} ATR) | Mínimo {min20:.{c}f} ({(min20 - preco) / atr:+.1f} ATR)

SCORE TÉCNICO FIXO: {sinal_det} ({score:+.1f}; limiar ±2,5) — {', '.join(razoes)}

CONFLUÊNCIA ENTRE TIMEFRAMES:
{txt_mtf}

ÚLTIMAS 20 VELAS (data | O H L C | RSI | MACD hist):
{velas}

EVENTOS ECONÓMICOS ({'/'.join(_moedas(par))}):
{txt_eventos}

NOTÍCIAS:
{txt_noticias}

Referência de risco: SL 1×ATR = {atr:.{c}f}; TP 2×ATR = {2 * atr:.{c}f}.
Decide e regista o sinal."""
    extra = {"score": score, "sinal_det": sinal_det, "razoes": razoes,
             "atr_percentil": round(atr_pct_rank), "max20": max20, "min20": min20}
    return prompt, extra


# ──────────────────────────────────────────────────────────────────────
# Validação e apresentação
# ──────────────────────────────────────────────────────────────────────

def _validar(ia: dict, preco: float, atr: float, eventos: list[dict] | None,
             timeframe: str) -> dict:
    """Aplica regras duras ao que o modelo devolveu. O código tem a última palavra."""
    modelo = str(ia.get("sinal", "AGUARDAR")).upper()
    final = modelo if modelo in ("COMPRAR", "VENDER") else "AGUARDAR"
    conf = int(ia.get("confianca", 0) or 0)
    ajustes: list[str] = []
    sl = tp = rr = None

    if final != "AGUARDAR":
        d = 1 if final == "COMPRAR" else -1
        sl = float(ia.get("stop_loss") or 0)
        tp = float(ia.get("take_profit") or 0)
        if d * (preco - sl) <= 0 or d * (tp - preco) <= 0:
            sl, tp = preco - d * atr, preco + d * 2 * atr
            ajustes.append("SL/TP do modelo incoerentes com a direção; usados 1×/2× ATR.")
        dist = abs(preco - sl) / atr
        if dist < 0.8 or dist > 2.5:
            limite = min(max(dist, 0.8), 2.5)
            sl = preco - d * limite * atr
            ajustes.append(f"Stop ajustado de {dist:.1f} para {limite:.1f} × ATR.")
        rr = abs(tp - preco) / abs(preco - sl)

        motivo = None
        if conf < CONFIANCA_MINIMA:
            motivo = f"confiança {conf} abaixo do mínimo {CONFIANCA_MINIMA}"
        elif rr < RR_MINIMO:
            motivo = f"risco/recompensa {rr:.2f} abaixo de {RR_MINIMO}"
        elif eventos and timeframe not in ("Diário", "Semanal"):
            proximo = next((e for e in eventos if e["impacto"] == "alto"
                            and -0.5 <= e["horas"] <= HORAS_BLOQUEIO_EVENTO), None)
            if proximo:
                motivo = f"evento de impacto alto: {proximo['pais']} {proximo['evento']}"
        if motivo:
            ajustes.append(f"{modelo} convertido em AGUARDAR — {motivo}.")
            final = "AGUARDAR"

    return {"sinal": final, "sinal_modelo": modelo, "confianca": conf,
            "stop_loss": sl, "take_profit": tp, "rr": round(rr, 2) if rr else None,
            "ajustes": ajustes}


def _texto_analise(par: str, timeframe: str, ia: dict, v: dict, c: int) -> str:
    conf = v["confianca"]
    nivel = "Alta" if conf >= 75 else ("Média" if conf >= 60 else "Baixa")
    linhas = [
        f"🎯 SINAL: {v['sinal']}",
        f"📈 CONFIANÇA: {conf}/100 ({nivel})",
        f"⏱️ TIMEFRAME: {timeframe}",
        "",
        "📊 ANÁLISE TÉCNICA:",
        *[f"- {x}" for x in ia.get("analise_tecnica", [])],
        "",
        "📰 NOTÍCIAS E EVENTOS:",
        f"- {ia.get('noticias', 'Sem impacto relevante')}",
        "",
        "📝 JUSTIFICAÇÃO FINAL:",
        f"- {ia.get('justificacao', '')}",
    ]
    if v["sinal"] != "AGUARDAR":
        linhas += [
            "",
            "🛡️ GESTÃO DE RISCO:",
            f"- Stop Loss: {v['stop_loss']:.{c}f}",
            f"- Take Profit: {v['take_profit']:.{c}f}",
            f"- Risco/Recompensa: 1:{v['rr']:.2f}",
        ]
    linhas += ["", f"❌ INVALIDAÇÃO: {ia.get('invalidacao', '')}"]
    if ia.get("riscos"):
        linhas += ["", "⚠️ RISCOS:", *[f"- {r}" for r in ia["riscos"]]]
    if v["ajustes"]:
        linhas += ["", "🔧 AJUSTES AUTOMÁTICOS:", *[f"- {a}" for a in v["ajustes"]]]
    linhas += ["", "⚠️ DISCLAIMER: Isto não é aconselhamento financeiro."]
    return "\n".join(linhas)


def _registar_sinal(registo: dict) -> None:
    """Guarda cada decisão em JSONL para depois medir a taxa de acerto real."""
    try:
        DIR_DADOS.mkdir(parents=True, exist_ok=True)
        with open(DIR_DADOS / "sinais_ia.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(registo, ensure_ascii=False, default=str) + "\n")
    except OSError as exc:
        log.warning("Não foi possível registar o sinal: %s", exc)


_cache_sinais: dict[tuple[str, str, str], tuple[float, dict]] = {}
_lock_sinais = threading.Lock()
TTL_SINAL = 300  # segundos; e só enquanto a vela for a mesma


def sinal(par: str, timeframe: str) -> dict:
    df = _df_par(par, timeframe)
    ind = indicadores_do_par(par, timeframe, df)
    chave = (par, timeframe, str(df.index[-1]))
    with _lock_sinais:
        item = _cache_sinais.get(chave)
        if item and time.time() - item[0] < TTL_SINAL:
            return {**ind, **item[1], "em_cache": True}

    moedas = _moedas(par)
    noticias = _noticias_do_par(moedas)
    eventos = _eventos_proximos(moedas)
    mtf = _confluencia_do_par(par)
    prompt, extra = _montar_prompt(par, timeframe, df, noticias, eventos, mtf)
    c = _casas(par)

    try:
        ia = claude.perguntar_estruturado(SYSTEM_PROMPT, prompt, FERRAMENTA_SINAL)
    except anthropic.APIError as exc:
        # Sem modelo: devolve o score fixo, claramente identificado.
        log.warning("Claude indisponível, a usar score fixo: %s", exc)
        ia = {"sinal": "AGUARDAR", "confianca": 0, "stop_loss": 0, "take_profit": 0,
              "invalidacao": "-", "analise_tecnica": [f"Score fixo: {extra['sinal_det']} "
              f"({extra['score']:+.1f}) — {', '.join(extra['razoes'])}"],
              "noticias": "Não analisadas.", "justificacao":
              "Modelo indisponível neste momento; sem análise da IA não é emitido sinal.",
              "riscos": []}

    v = _validar(ia, ind["preco"], ind["atr"], eventos, timeframe)
    resultado = {
        "analise": _texto_analise(par, timeframe, ia, v, c),
        "noticias": noticias,
        "eventos": eventos or [],
        "confluencia": mtf,
        "ia": {**v, "invalidacao": ia.get("invalidacao"), "score_fixo": extra["score"]},
    }
    _registar_sinal({
        "momento": pd.Timestamp.now(tz="UTC").isoformat(timespec="seconds"), "par": par,
        "ticker": PARES[par],
        "timeframe": timeframe, "vela": chave[2], "preco": ind["preco"], "atr": ind["atr"],
        "modelo": MODELO, **v, "score_fixo": extra["score"],
        "atr_percentil": extra["atr_percentil"],
    })
    with _lock_sinais:
        _cache_sinais[chave] = (time.time(), resultado)
    return {**ind, **resultado}


def sentimento() -> dict:
    titulos = finnhub.noticias(limite=8)
    noticias = "\n".join(f"- {t}" for t in titulos) if titulos else "Sem notícias."

    tickers = [PARES[n] for n in PARES_SENTIMENTO]
    dados = mercado.historico(tickers, "5d", "1d", ttl=600)
    variacoes = []
    for nome in PARES_SENTIMENTO:
        df = dados.get(PARES[nome])
        if df is None or len(df) < 2:
            continue
        try:
            primeiro, ultimo = float(df["Close"].iloc[0]), float(df["Close"].iloc[-1])
            if primeiro:
                variacoes.append(
                    {"par": nome, "variacao": round((ultimo - primeiro) / primeiro * 100, 2)}
                )
        except (ValueError, TypeError, IndexError):
            continue

    texto_var = "\n".join(f"{v['par']}: {v['variacao']:+.2f}%" for v in variacoes)
    prompt = (
        f"NOTÍCIAS:\n{noticias}\n\nVARIAÇÕES:\n{texto_var or 'Indisponíveis.'}"
        "\n\nFaz a análise de sentimento."
    )
    return {
        "analise": claude.perguntar(SENTIMENTO_PROMPT, prompt, max_tokens=1300),
        "variacoes": variacoes,
        "noticias": titulos,
    }


def calendario(dias: int = 7) -> dict:
    if not finnhub.chave:
        raise RuntimeError("FINNHUB_API_KEY não configurada no servidor.")
    eventos = finnhub.calendario(dias=dias)
    eventos.sort(key=lambda x: str(x.get("time", "")))

    saida = []
    for ev in eventos:
        impacto = str(ev.get("impact", "")).lower()
        if "high" in impacto or impacto == "3":
            nivel = "alto"
        elif "medium" in impacto or impacto == "2":
            nivel = "medio"
        else:
            nivel = "baixo"
        saida.append({
            "quando": str(ev.get("time", ""))[:16].replace("T", " "),
            "pais": ev.get("country", ""),
            "evento": ev.get("event", ""),
            "impacto": nivel,
            "anterior": ev.get("prev", "-"),
            "estimativa": ev.get("estimate", "-"),
            "atual": ev.get("actual", "-"),
        })
    return {"dias": dias, "eventos": saida}


def verificar_alertas() -> list[dict]:
    ativos = alertas.listar()
    if not ativos:
        return []
    tickers = sorted({a["ticker"] for a in ativos})
    precos = mercado.precos_atuais(tickers)
    disparados = alertas.verificar(precos)
    for a in disparados:
        notificar_telegram(
            f"🔔 Alerta de preço\n{a['par']} {a['condicao'].lower()} {a['preco']}\n"
            f"Preço atual: {a['preco_disparo']:.5f}"
        )
    return disparados


# ──────────────────────────────────────────────────────────────────────
# Melhor oportunidade (confluência entre timeframes)
# ──────────────────────────────────────────────────────────────────────

# Timeframes usados na confluência e o peso de cada um. O 4h pesa mais
# porque define a tendência; o 15m pesa menos porque é o mais ruidoso.
PESOS_CONFLUENCIA: dict[str, float] = {
    "15 minutos": 0.5,
    "1 hora": 1.0,
    "4 horas": 1.5,
    "Diário": 1.0,
}

# Abaixo deste ATR (em % do preço) o instrumento está parado e não
# compensa operar, por muito alinhados que estejam os indicadores.
ATR_MINIMO_PCT = 0.05


def _scores_por_timeframe(nome_tf: str) -> dict[str, dict]:
    """Pontua todos os pares num timeframe. Um download em lote só."""
    tf = TIMEFRAMES.get(nome_tf)
    if tf is None:
        return {}

    dados = mercado.historico(list(PARES.values()), tf.periodo, tf.intervalo, ttl=120)
    saida: dict[str, dict] = {}
    for nome, ticker in PARES.items():
        df = dados.get(ticker)
        if df is None:
            continue
        if tf.reamostrar:
            df = reamostrar(df, tf.reamostrar)
        df = calcular_indicadores(df)
        if df is None:
            continue
        u = df.iloc[-1]
        rsi, ema9, ema21 = float(u["RSI"]), float(u["EMA9"]), float(u["EMA21"])
        atr, hist, preco = float(u["ATR"]), float(u["MACD_hist"]), float(u["Close"])
        sinal, score, razoes = pontuar(rsi, ema9, ema21, hist)
        saida[nome] = {
            "sinal": sinal,
            "score": round(score, 1),
            "rsi": round(rsi, 1),
            "atr": atr,
            "preco": preco,
            "razoes": razoes,
        }
    return saida


def melhor() -> dict:
    """Cruza todos os pares com todos os timeframes e ordena-os por
    confluência: força do sinal x concordância entre timeframes."""
    por_tf = {nome: _scores_por_timeframe(nome) for nome in PESOS_CONFLUENCIA}
    if not any(por_tf.values()):
        raise RuntimeError("Não foi possível obter cotações do Yahoo Finance.")

    candidatos = []
    for par in PARES:
        entradas = {tf: dados[par] for tf, dados in por_tf.items() if par in dados}
        if len(entradas) < 2:
            continue  # sem dados suficientes para falar de confluência

        peso_total = sum(PESOS_CONFLUENCIA[tf] for tf in entradas)
        ponderado = (
            sum(e["score"] * PESOS_CONFLUENCIA[tf] for tf, e in entradas.items())
            / peso_total
        )

        # Que fração dos timeframes aponta para o mesmo lado do ponderado?
        direcao = 1 if ponderado > 0 else -1
        alinhados = sum(
            1 for e in entradas.values() if (1 if e["score"] > 0 else -1) == direcao
        )
        concordancia = alinhados / len(entradas)

        referencia = entradas.get("1 hora") or next(iter(entradas.values()))
        preco = referencia["preco"]
        atr_pct = (referencia["atr"] / preco * 100) if preco else 0.0

        # Timeframe ideal: entre os que concordam com a direção, aquele em
        # que o setup está mais nítido. Empate desfeito a favor do timeframe
        # mais lento, que é o menos ruidoso.
        concordantes = {
            tf: e for tf, e in entradas.items()
            if (1 if e["score"] > 0 else -1) == direcao
        }
        escolha = concordantes or entradas
        lentidao = list(PESOS_CONFLUENCIA).index  # 15m=0 ... Diário=3
        tf_ideal = max(
            escolha,
            key=lambda tf: (abs(escolha[tf]["score"]), lentidao(tf)),
        )
        e_ideal = escolha[tf_ideal]
        razao_ideal = (
            f"score {e_ideal['score']:+.1f} e RSI {e_ideal['rsi']:.0f} — "
            + ("o mais nítido dos que concordam"
               if concordantes else "nenhum timeframe concorda com os outros")
        )

        forca = abs(ponderado) * concordancia
        if atr_pct < ATR_MINIMO_PCT:
            forca *= 0.5  # alinhado mas sem movimento: vale metade

        if forca >= 3.0:
            qualidade = "Forte"
        elif forca >= 2.0:
            qualidade = "Moderado"
        else:
            qualidade = "Fraco"

        candidatos.append({
            "par": par,
            "direcao": "COMPRA" if direcao > 0 else "VENDA",
            "forca": round(forca, 2),
            "qualidade": qualidade,
            "concordancia": round(concordancia * 100),
            "timeframes_alinhados": f"{alinhados}/{len(entradas)}",
            "timeframe_ideal": tf_ideal,
            "razao_timeframe": razao_ideal,
            "score_ponderado": round(ponderado, 2),
            "preco": round(preco, 5),
            "atr_pct": round(atr_pct, 3),
            "parado": atr_pct < ATR_MINIMO_PCT,
            "detalhe": {
                tf: {"sinal": e["sinal"], "score": e["score"], "rsi": e["rsi"]}
                for tf, e in entradas.items()
            },
        })

    candidatos.sort(key=lambda c: c["forca"], reverse=True)
    return {
        "momento": datetime.now().isoformat(timespec="seconds"),
        "timeframes": list(PESOS_CONFLUENCIA),
        "melhor": candidatos[0] if candidatos else None,
        "ranking": candidatos,
    }


def config() -> dict:
    return {
        "pares": list(PARES),
        "timeframes": {k: asdict(v) for k, v in TIMEFRAMES.items()},
        "modelo": MODELO,
        "finnhub": bool(finnhub.chave),
        "telegram": bool(
            os.getenv("TELEGRAM_BOT_TOKEN") and os.getenv("TELEGRAM_CHAT_ID")
        ),
    }
