"""
Motor do Forex Advisor — lógica partilhada, sem interface.

Reutiliza a mesma estratégia da versão desktop (RSI/EMA/ATR/MACD + pontuação),
mas devolve estruturas de dados em vez de texto formatado, para o frontend
web poder renderizar como quiser.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from logging.handlers import RotatingFileHandler
from pathlib import Path

import anthropic
import pandas as pd
import requests
import ta
import yfinance as yf

# ──────────────────────────────────────────────────────────────────────
# Configuração
# ──────────────────────────────────────────────────────────────────────

APP_NOME = "Forex Advisor"
DIR_DADOS = Path(os.getenv("FOREX_DATA_DIR", "/var/lib/forex-advisor"))
MODELO = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5")

log = logging.getLogger("forex")


def configurar_log() -> None:
    if log.handlers:
        return
    log.setLevel(logging.INFO)
    try:
        DIR_DADOS.mkdir(parents=True, exist_ok=True)
        handler: logging.Handler = RotatingFileHandler(
            DIR_DADOS / "app.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8"
        )
    except OSError:
        handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-7s | %(message)s"))
    log.addHandler(handler)


# ──────────────────────────────────────────────────────────────────────
# Prompts
# ──────────────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """
És um analista técnico e fundamental de Forex profissional e disciplinado.

Responde SEMPRE neste formato:

🎯 SINAL: COMPRAR / VENDER / AGUARDAR
📈 CONFIANÇA: Baixa / Média / Alta
⏱️ TIMEFRAME: [timeframe]

📊 ANÁLISE TÉCNICA:
- Principais indicadores (incluindo ATR)

📰 SENTIMENTO DAS NOTÍCIAS:
- Sentimento geral

📝 JUSTIFICAÇÃO FINAL:
- Motivo do sinal

🛡️ GESTÃO DE RISCO (baseada em ATR):
- Stop Loss sugerido (1 × ATR)
- Take Profit sugerido (2 × ATR)
- Risco/Recompensa

⚠️ DISCLAIMER: Isto não é aconselhamento financeiro.
"""

SENTIMENTO_PROMPT = """
És um analista sénior de sentimento de mercado Forex.

Responde SEMPRE neste formato:

🌍 SENTIMENTO GERAL DO MERCADO: Risk-On / Risk-Off / Neutro

📊 FORÇA DAS MOEDAS (de mais forte para mais fraca):
1.
2.
3.
4.
5.

📰 PRINCIPAIS CATALISADORES:
- Lista os fatores mais importantes

🎯 VIÉS ATUAL:
- USD: Forte / Fraco / Neutro
- EUR: Forte / Fraco / Neutro
- GBP: Forte / Fraco / Neutro
- JPY: Forte / Fraco / Neutro
- AUD: Forte / Fraco / Neutro

💡 CONCLUSÃO:
- Resumo objetivo

⚠️ DISCLAIMER: Isto não é aconselhamento financeiro.
"""

# ──────────────────────────────────────────────────────────────────────
# Instrumentos
# ──────────────────────────────────────────────────────────────────────

PARES: dict[str, str] = {
    "EUR/USD": "EURUSD=X",
    "GBP/USD": "GBPUSD=X",
    "USD/JPY": "USDJPY=X",
    "USD/CHF": "USDCHF=X",
    "AUD/USD": "AUDUSD=X",
    "USD/CAD": "USDCAD=X",
    "NZD/USD": "NZDUSD=X",
    "EUR/GBP": "EURGBP=X",
    "EUR/JPY": "EURJPY=X",
    "GBP/JPY": "GBPJPY=X",
    "AUD/JPY": "AUDJPY=X",
    "XAU/USD (Ouro)": "GC=F",
    "XAG/USD (Prata)": "SI=F",
}

PARES_SENTIMENTO = ["EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD", "XAU/USD (Ouro)"]


@dataclass(frozen=True)
class Timeframe:
    intervalo: str
    periodo: str
    reamostrar: str | None = None


TIMEFRAMES: dict[str, Timeframe] = {
    "15 minutos": Timeframe("15m", "10d"),
    "1 hora": Timeframe("1h", "30d"),
    "4 horas": Timeframe("1h", "60d", reamostrar="4h"),
    "Diário": Timeframe("1d", "1y"),
    "Semanal": Timeframe("1wk", "2y"),
}

COLUNAS = ("Open", "High", "Low", "Close")

# ──────────────────────────────────────────────────────────────────────
# Dados de mercado
# ──────────────────────────────────────────────────────────────────────


class Mercado:
    """Downloads em lote com cache partilhada por todos os utilizadores."""

    TTL_PADRAO = 120

    def __init__(self) -> None:
        self._cache: dict[tuple[str, str, str], tuple[float, pd.DataFrame]] = {}
        self._lock = threading.Lock()

    def historico(
        self, tickers: list[str], periodo: str, intervalo: str, ttl: int | None = None
    ) -> dict[str, pd.DataFrame]:
        ttl = self.TTL_PADRAO if ttl is None else ttl
        agora = time.time()
        resultado: dict[str, pd.DataFrame] = {}
        em_falta: list[str] = []

        with self._lock:
            for t in tickers:
                item = self._cache.get((t, periodo, intervalo))
                if item and agora - item[0] < ttl:
                    resultado[t] = item[1]
                else:
                    em_falta.append(t)

        if em_falta:
            novos = self._descarregar(em_falta, periodo, intervalo)
            if novos:
                with self._lock:
                    for t, df in novos.items():
                        self._cache[(t, periodo, intervalo)] = (agora, df)
                resultado.update(novos)
        return resultado

    def _descarregar(self, tickers: list[str], periodo: str, intervalo: str) -> dict:
        try:
            bruto = yf.download(
                tickers, period=periodo, interval=intervalo, group_by="ticker",
                auto_adjust=False, actions=False, progress=False, threads=True,
            )
        except Exception:
            log.exception("Erro no download %s %s/%s", tickers, periodo, intervalo)
            return {}

        if bruto is None or bruto.empty:
            log.warning("Sem dados para %s (%s/%s)", tickers, periodo, intervalo)
            return {}

        saida: dict[str, pd.DataFrame] = {}
        if isinstance(bruto.columns, pd.MultiIndex):
            disponiveis = set(bruto.columns.get_level_values(0))
            for t in tickers:
                if t in disponiveis:
                    df = self._normalizar(bruto[t])
                    if df is not None:
                        saida[t] = df
        else:
            df = self._normalizar(bruto)
            if df is not None and tickers:
                saida[tickers[0]] = df
        return saida

    @staticmethod
    def _normalizar(df):
        if df is None or df.empty:
            return None
        df = df.copy()
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)
        if not all(c in df.columns for c in COLUNAS):
            return None
        df = df.dropna(subset=list(COLUNAS))
        return df if not df.empty else None

    def precos_atuais(self, tickers: list[str]) -> dict[str, float]:
        for periodo, intervalo, ttl in (("1d", "1m", 20), ("5d", "1h", 60)):
            dados = self.historico(tickers, periodo, intervalo, ttl=ttl)
            if dados:
                precos = {}
                for t, df in dados.items():
                    try:
                        precos[t] = float(df["Close"].iloc[-1])
                    except (IndexError, ValueError, TypeError):
                        continue
                if precos:
                    return precos
        return {}


def reamostrar(df: pd.DataFrame, regra: str) -> pd.DataFrame:
    agregacao = {"Open": "first", "High": "max", "Low": "min", "Close": "last"}
    if "Volume" in df.columns:
        agregacao["Volume"] = "sum"
    return df.resample(regra).agg(agregacao).dropna(subset=list(COLUNAS))


def calcular_indicadores(df, minimo: int = 40):
    if df is None or len(df) < minimo:
        return None
    df = df.copy()
    fecho, maximo, minimo_col = df["Close"], df["High"], df["Low"]

    df["RSI"] = ta.momentum.RSIIndicator(fecho, window=14).rsi()
    df["EMA9"] = ta.trend.EMAIndicator(fecho, window=9).ema_indicator()
    df["EMA21"] = ta.trend.EMAIndicator(fecho, window=21).ema_indicator()
    df["ATR"] = ta.volatility.AverageTrueRange(
        maximo, minimo_col, fecho, window=14
    ).average_true_range()

    macd = ta.trend.MACD(fecho)
    df["MACD"] = macd.macd()
    df["MACD_signal"] = macd.macd_signal()
    df["MACD_hist"] = macd.macd_diff()

    df = df.dropna(subset=["RSI", "EMA9", "EMA21", "ATR", "MACD_hist"])
    return df if not df.empty else None


def pontuar(rsi: float, ema9: float, ema21: float, macd_hist: float):
    """Pontuação idêntica à da versão desktop."""
    score = 0.0
    razoes: list[str] = []

    if rsi < 35:
        score += 2
        razoes.append("RSI baixo")
    elif rsi > 65:
        score -= 2
        razoes.append("RSI alto")

    if ema9 > ema21:
        score += 1.5
        razoes.append("EMA+")
    else:
        score -= 1.5
        razoes.append("EMA-")

    if macd_hist > 0:
        score += 1
        razoes.append("MACD+")
    else:
        score -= 1
        razoes.append("MACD-")

    if score >= 2.5:
        sinal = "COMPRA"
    elif score <= -2.5:
        sinal = "VENDA"
    else:
        sinal = "NEUTRO"
    return sinal, score, razoes


# ──────────────────────────────────────────────────────────────────────
# Serviços externos
# ──────────────────────────────────────────────────────────────────────


class Finnhub:
    BASE = "https://finnhub.io/api/v1"

    def __init__(self) -> None:
        self._sessao: requests.Session | None = None
        self._lock = threading.Lock()

    @property
    def chave(self) -> str:
        return os.getenv("FINNHUB_API_KEY", "").strip()

    def _get(self, caminho: str, params: dict, timeout: int = 10):
        with self._lock:
            if self._sessao is None:
                self._sessao = requests.Session()
                self._sessao.headers.update({"User-Agent": APP_NOME})
        resposta = self._sessao.get(
            f"{self.BASE}{caminho}", params={**params, "token": self.chave}, timeout=timeout
        )
        resposta.raise_for_status()
        return resposta.json()

    def noticias(self, limite: int = 8) -> list[str]:
        if not self.chave:
            return []
        try:
            dados = self._get("/news", {"category": "forex"}, timeout=8)
            if isinstance(dados, list):
                return [
                    item["headline"].strip()
                    for item in dados[:limite]
                    if item.get("headline")
                ]
        except Exception as exc:
            log.warning("Finnhub notícias: %s", exc)
        return []

    def calendario(self, dias: int = 7) -> list[dict]:
        hoje = datetime.now().date()
        dados = self._get(
            "/calendar/economic",
            {"from": str(hoje), "to": str(hoje + timedelta(days=dias))},
            timeout=12,
        )
        if isinstance(dados, dict):
            if dados.get("error"):
                raise RuntimeError(str(dados["error"]))
            return dados.get("economicCalendar") or []
        return []


class Claude:
    def __init__(self) -> None:
        self._cliente: anthropic.Anthropic | None = None
        self._lock = threading.Lock()

    def cliente(self) -> anthropic.Anthropic:
        chave = os.getenv("ANTHROPIC_API_KEY", "").strip()
        if not chave:
            raise RuntimeError("ANTHROPIC_API_KEY não configurada no servidor.")
        with self._lock:
            if self._cliente is None:
                self._cliente = anthropic.Anthropic(api_key=chave, timeout=60.0, max_retries=2)
        return self._cliente

    def perguntar(self, system: str, prompt: str, max_tokens: int = 1500) -> str:
        resposta = self.cliente().messages.create(
            model=MODELO, max_tokens=max_tokens, system=system,
            messages=[{"role": "user", "content": prompt}],
        )
        texto = "".join(
            b.text for b in resposta.content if getattr(b, "type", "") == "text"
        )
        return texto.strip() or "Sem resposta do modelo."


# ──────────────────────────────────────────────────────────────────────
# Alertas
# ──────────────────────────────────────────────────────────────────────


class GestorAlertas:
    def __init__(self, ficheiro: Path | None = None) -> None:
        self.ficheiro = ficheiro or (DIR_DADOS / "alertas.json")
        self._lock = threading.Lock()
        self._proximo_id = 1
        self._alertas: list[dict] = self._ler()

    def _ler(self) -> list[dict]:
        try:
            if self.ficheiro.is_file():
                dados = json.loads(self.ficheiro.read_text(encoding="utf-8"))
                validos = [d for d in dados if isinstance(d, dict) and d.get("par") in PARES]
                if validos:
                    self._proximo_id = max(int(d.get("id", 0)) for d in validos) + 1
                return validos
        except Exception:
            log.exception("Não foi possível ler os alertas")
        return []

    def _gravar(self) -> None:
        try:
            self.ficheiro.parent.mkdir(parents=True, exist_ok=True)
            temporario = self.ficheiro.with_suffix(".tmp")
            temporario.write_text(
                json.dumps(self._alertas, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            temporario.replace(self.ficheiro)  # escrita atómica
        except Exception:
            log.exception("Não foi possível gravar os alertas")

    def adicionar(self, par: str, condicao: str, preco: float) -> dict:
        if par not in PARES:
            raise ValueError("Par desconhecido.")
        if condicao not in ("Acima de", "Abaixo de"):
            raise ValueError("Condição inválida.")
        if not (preco > 0):
            raise ValueError("Preço tem de ser maior que zero.")
        with self._lock:
            alerta = {
                "id": self._proximo_id,
                "par": par,
                "ticker": PARES[par],
                "condicao": condicao,
                "preco": float(preco),
                "ativo": True,
                "criado": datetime.now().isoformat(timespec="seconds"),
            }
            self._proximo_id += 1
            self._alertas.append(alerta)
            self._gravar()
            return dict(alerta)

    def remover(self, id_alerta: int) -> bool:
        with self._lock:
            antes = len(self._alertas)
            self._alertas = [a for a in self._alertas if a.get("id") != id_alerta]
            if len(self._alertas) != antes:
                self._gravar()
                return True
            return False

    def listar(self, apenas_ativos: bool = True) -> list[dict]:
        with self._lock:
            return [
                dict(a) for a in self._alertas if a.get("ativo") or not apenas_ativos
            ]

    def verificar(self, precos: dict[str, float]) -> list[dict]:
        disparados: list[dict] = []
        with self._lock:
            for alerta in self._alertas:
                if not alerta.get("ativo"):
                    continue
                atual = precos.get(alerta["ticker"])
                if atual is None:
                    continue
                acima = alerta["condicao"] == "Acima de" and atual >= alerta["preco"]
                abaixo = alerta["condicao"] == "Abaixo de" and atual <= alerta["preco"]
                if acima or abaixo:
                    alerta["ativo"] = False
                    alerta["disparado_em"] = datetime.now().isoformat(timespec="seconds")
                    alerta["preco_disparo"] = atual
                    disparados.append(dict(alerta))
            if disparados:
                self._gravar()
        return disparados


def notificar_telegram(mensagem: str) -> bool:
    """Envia para o Telegram se BOT_TOKEN e CHAT_ID estiverem definidos."""
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat:
        return False
    try:
        r = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat, "text": mensagem},
            timeout=10,
        )
        r.raise_for_status()
        return True
    except Exception as exc:
        log.warning("Telegram: %s", exc)
        return False


# ──────────────────────────────────────────────────────────────────────
# Operações de alto nível
# ──────────────────────────────────────────────────────────────────────

mercado = Mercado()
finnhub = Finnhub()
claude = Claude()
alertas = GestorAlertas()


def scan() -> dict:
    dados = mercado.historico(list(PARES.values()), "30d", "1h", ttl=120)
    if not dados:
        raise RuntimeError("Não foi possível obter cotações do Yahoo Finance.")

    linhas = []
    for nome, ticker in PARES.items():
        df = calcular_indicadores(dados.get(ticker))
        if df is None:
            continue
        u = df.iloc[-1]
        rsi, ema9, ema21 = float(u["RSI"]), float(u["EMA9"]), float(u["EMA21"])
        atr, hist = float(u["ATR"]), float(u["MACD_hist"])
        sinal, score, razoes = pontuar(rsi, ema9, ema21, hist)
        linhas.append({
            "par": nome,
            "sinal": sinal,
            "score": round(score, 1),
            "rsi": round(rsi, 1),
            "atr": round(atr, 5),
            "preco": round(float(u["Close"]), 5),
            "razoes": razoes,
        })

    linhas.sort(key=lambda x: x["score"], reverse=True)
    return {
        "momento": datetime.now().isoformat(timespec="seconds"),
        "total": len(linhas),
        "resultados": linhas,
    }


def indicadores_do_par(par: str, timeframe: str) -> dict:
    if par not in PARES:
        raise ValueError("Par desconhecido.")
    if timeframe not in TIMEFRAMES:
        raise ValueError("Timeframe desconhecido.")

    tf = TIMEFRAMES[timeframe]
    ticker = PARES[par]
    dados = mercado.historico([ticker], tf.periodo, tf.intervalo, ttl=60)
    df = dados.get(ticker)
    if df is None:
        raise RuntimeError("Dados insuficientes para este par/timeframe.")

    if tf.reamostrar:
        df = reamostrar(df, tf.reamostrar)

    df = calcular_indicadores(df)
    if df is None:
        raise RuntimeError("Dados insuficientes para calcular indicadores.")

    u = df.iloc[-1]
    atr = float(u["ATR"])
    return {
        "par": par,
        "timeframe": timeframe,
        "preco": float(u["Close"]),
        "rsi": float(u["RSI"]),
        "ema9": float(u["EMA9"]),
        "ema21": float(u["EMA21"]),
        "atr": atr,
        "macd": float(u["MACD"]),
        "macd_signal": float(u["MACD_signal"]),
        "macd_hist": float(u["MACD_hist"]),
        "stop_loss": atr,
        "take_profit": atr * 2,
        "velas": [
            {"t": str(i), "c": round(float(c), 5)}
            for i, c in df["Close"].tail(120).items()
        ],
    }


def sinal(par: str, timeframe: str) -> dict:
    ind = indicadores_do_par(par, timeframe)
    titulos = finnhub.noticias(limite=5)
    noticias = "\n".join(f"• {t}" for t in titulos) if titulos else "Sem notícias."

    prompt = f"""
Par: {ind['par']} | Timeframe: {ind['timeframe']} | Preço: {ind['preco']:.5f}

INDICADORES:
RSI: {ind['rsi']:.2f} | EMA9: {ind['ema9']:.5f} | EMA21: {ind['ema21']:.5f}
ATR: {ind['atr']:.5f} | MACD: {ind['macd']:.5f} | Signal: {ind['macd_signal']:.5f} | Hist: {ind['macd_hist']:.5f}

GESTÃO DE RISCO (ATR):
Stop Loss: {ind['stop_loss']:.5f} (1×ATR) | Take Profit: {ind['take_profit']:.5f} (2×ATR)

NOTÍCIAS:
{noticias}

Dá o sinal completo.
"""
    ind["analise"] = claude.perguntar(SYSTEM_PROMPT, prompt, max_tokens=1500)
    ind["noticias"] = titulos
    return ind


def sentimento() -> dict:
    titulos = finnhub.noticias(limite=8)
    noticias = "\n".join(f"- {t}" for t in titulos) if titulos else "Sem notícias."

    tickers = [PARES[n] for n in PARES_SENTIMENTO]
    dados = mercado.historico(tickers, "5d", "1d", ttl=600)
    variacoes = []
    for nome in PARES_SENTIMENTO:
        df = dados.get(PARES[nome])
        if df is None or len(df) < 2:
            continue
        try:
            primeiro, ultimo = float(df["Close"].iloc[0]), float(df["Close"].iloc[-1])
            if primeiro:
                variacoes.append(
                    {"par": nome, "variacao": round((ultimo - primeiro) / primeiro * 100, 2)}
                )
        except (ValueError, TypeError, IndexError):
            continue

    texto_var = "\n".join(f"{v['par']}: {v['variacao']:+.2f}%" for v in variacoes)
    prompt = (
        f"NOTÍCIAS:\n{noticias}\n\nVARIAÇÕES:\n{texto_var or 'Indisponíveis.'}"
        "\n\nFaz a análise de sentimento."
    )
    return {
        "analise": claude.perguntar(SENTIMENTO_PROMPT, prompt, max_tokens=1300),
        "variacoes": variacoes,
        "noticias": titulos,
    }


def calendario(dias: int = 7) -> dict:
    if not finnhub.chave:
        raise RuntimeError("FINNHUB_API_KEY não configurada no servidor.")
    eventos = finnhub.calendario(dias=dias)
    eventos.sort(key=lambda x: str(x.get("time", "")))

    saida = []
    for ev in eventos:
        impacto = str(ev.get("impact", "")).lower()
        if "high" in impacto or impacto == "3":
            nivel = "alto"
        elif "medium" in impacto or impacto == "2":
            nivel = "medio"
        else:
            nivel = "baixo"
        saida.append({
            "quando": str(ev.get("time", ""))[:16].replace("T", " "),
            "pais": ev.get("country", ""),
            "evento": ev.get("event", ""),
            "impacto": nivel,
            "anterior": ev.get("prev", "-"),
            "estimativa": ev.get("estimate", "-"),
            "atual": ev.get("actual", "-"),
        })
    return {"dias": dias, "eventos": saida}


def verificar_alertas() -> list[dict]:
    ativos = alertas.listar()
    if not ativos:
        return []
    tickers = sorted({a["ticker"] for a in ativos})
    precos = mercado.precos_atuais(tickers)
    disparados = alertas.verificar(precos)
    for a in disparados:
        notificar_telegram(
            f"🔔 Alerta de preço\n{a['par']} {a['condicao'].lower()} {a['preco']}\n"
            f"Preço atual: {a['preco_disparo']:.5f}"
        )
    return disparados


# ──────────────────────────────────────────────────────────────────────
# Melhor oportunidade (confluência entre timeframes)
# ──────────────────────────────────────────────────────────────────────

# Timeframes usados na confluência e o peso de cada um. O 4h pesa mais
# porque define a tendência; o 15m pesa menos porque é o mais ruidoso.
PESOS_CONFLUENCIA: dict[str, float] = {
    "15 minutos": 0.5,
    "1 hora": 1.0,
    "4 horas": 1.5,
    "Diário": 1.0,
}

# Abaixo deste ATR (em % do preço) o instrumento está parado e não
# compensa operar, por muito alinhados que estejam os indicadores.
ATR_MINIMO_PCT = 0.05


def _scores_por_timeframe(nome_tf: str) -> dict[str, dict]:
    """Pontua todos os pares num timeframe. Um download em lote só."""
    tf = TIMEFRAMES.get(nome_tf)
    if tf is None:
        return {}

    dados = mercado.historico(list(PARES.values()), tf.periodo, tf.intervalo, ttl=120)
    saida: dict[str, dict] = {}
    for nome, ticker in PARES.items():
        df = dados.get(ticker)
        if df is None:
            continue
        if tf.reamostrar:
            df = reamostrar(df, tf.reamostrar)
        df = calcular_indicadores(df)
        if df is None:
            continue
        u = df.iloc[-1]
        rsi, ema9, ema21 = float(u["RSI"]), float(u["EMA9"]), float(u["EMA21"])
        atr, hist, preco = float(u["ATR"]), float(u["MACD_hist"]), float(u["Close"])
        sinal, score, razoes = pontuar(rsi, ema9, ema21, hist)
        saida[nome] = {
            "sinal": sinal,
            "score": round(score, 1),
            "rsi": round(rsi, 1),
            "atr": atr,
            "preco": preco,
            "razoes": razoes,
        }
    return saida


def melhor() -> dict:
    """Cruza todos os pares com todos os timeframes e ordena-os por
    confluência: força do sinal x concordância entre timeframes."""
    por_tf = {nome: _scores_por_timeframe(nome) for nome in PESOS_CONFLUENCIA}
    if not any(por_tf.values()):
        raise RuntimeError("Não foi possível obter cotações do Yahoo Finance.")

    candidatos = []
    for par in PARES:
        entradas = {tf: dados[par] for tf, dados in por_tf.items() if par in dados}
        if len(entradas) < 2:
            continue  # sem dados suficientes para falar de confluência

        peso_total = sum(PESOS_CONFLUENCIA[tf] for tf in entradas)
        ponderado = (
            sum(e["score"] * PESOS_CONFLUENCIA[tf] for tf, e in entradas.items())
            / peso_total
        )

        # Que fração dos timeframes aponta para o mesmo lado do ponderado?
        direcao = 1 if ponderado > 0 else -1
        alinhados = sum(
            1 for e in entradas.values() if (1 if e["score"] > 0 else -1) == direcao
        )
        concordancia = alinhados / len(entradas)

        referencia = entradas.get("1 hora") or next(iter(entradas.values()))
        preco = referencia["preco"]
        atr_pct = (referencia["atr"] / preco * 100) if preco else 0.0

        # Timeframe ideal: entre os que concordam com a direção, aquele em
        # que o setup está mais nítido. Empate desfeito a favor do timeframe
        # mais lento, que é o menos ruidoso.
        concordantes = {
            tf: e for tf, e in entradas.items()
            if (1 if e["score"] > 0 else -1) == direcao
        }
        escolha = concordantes or entradas
        lentidao = list(PESOS_CONFLUENCIA).index  # 15m=0 ... Diário=3
        tf_ideal = max(
            escolha,
            key=lambda tf: (abs(escolha[tf]["score"]), lentidao(tf)),
        )
        e_ideal = escolha[tf_ideal]
        razao_ideal = (
            f"score {e_ideal['score']:+.1f} e RSI {e_ideal['rsi']:.0f} — "
            + ("o mais nítido dos que concordam"
               if concordantes else "nenhum timeframe concorda com os outros")
        )

        forca = abs(ponderado) * concordancia
        if atr_pct < ATR_MINIMO_PCT:
            forca *= 0.5  # alinhado mas sem movimento: vale metade

        if forca >= 3.0:
            qualidade = "Forte"
        elif forca >= 2.0:
            qualidade = "Moderado"
        else:
            qualidade = "Fraco"

        candidatos.append({
            "par": par,
            "direcao": "COMPRA" if direcao > 0 else "VENDA",
            "forca": round(forca, 2),
            "qualidade": qualidade,
            "concordancia": round(concordancia * 100),
            "timeframes_alinhados": f"{alinhados}/{len(entradas)}",
            "timeframe_ideal": tf_ideal,
            "razao_timeframe": razao_ideal,
            "score_ponderado": round(ponderado, 2),
            "preco": round(preco, 5),
            "atr_pct": round(atr_pct, 3),
            "parado": atr_pct < ATR_MINIMO_PCT,
            "detalhe": {
                tf: {"sinal": e["sinal"], "score": e["score"], "rsi": e["rsi"]}
                for tf, e in entradas.items()
            },
        })

    candidatos.sort(key=lambda c: c["forca"], reverse=True)
    return {
        "momento": datetime.now().isoformat(timespec="seconds"),
        "timeframes": list(PESOS_CONFLUENCIA),
        "melhor": candidatos[0] if candidatos else None,
        "ranking": candidatos,
    }


def config() -> dict:
    return {
        "pares": list(PARES),
        "timeframes": {k: asdict(v) for k, v in TIMEFRAMES.items()},
        "modelo": MODELO,
        "finnhub": bool(finnhub.chave),
        "telegram": bool(
            os.getenv("TELEGRAM_BOT_TOKEN") and os.getenv("TELEGRAM_CHAT_ID")
        ),
    }
