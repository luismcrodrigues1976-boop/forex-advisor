#!/usr/bin/env bash
#
# Instala o Forex Advisor no VPS. Idempotente — podes voltar a correr
# para atualizar o código.
#
#   scp -r forex-advisor root@135.181.203.253:/root/
#   ssh root@135.181.203.253
#   cd /root/forex-advisor && bash deploy/instalar.sh
#
set -euo pipefail

APP_DIR=/opt/forex-advisor
DATA_DIR=/var/lib/forex-advisor
ENV_FILE=/etc/forex-advisor.env
UTILIZADOR=forex
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ $EUID -ne 0 ]]; then
  echo "Corre como root (este script mexe em systemd e /opt)." >&2
  exit 1
fi

echo "==> Dependências do sistema"
apt-get update -qq
apt-get install -y -qq python3 python3-venv python3-pip

echo "==> Utilizador de serviço '$UTILIZADOR'"
id -u "$UTILIZADOR" &>/dev/null || useradd --system --no-create-home --shell /usr/sbin/nologin "$UTILIZADOR"

echo "==> Diretórios"
mkdir -p "$APP_DIR" "$DATA_DIR"

echo "==> Código"
install -m 644 "$ORIGEM/app.py"   "$APP_DIR/app.py"
install -m 644 "$ORIGEM/motor.py" "$APP_DIR/motor.py"
install -m 644 "$ORIGEM/requirements.txt" "$APP_DIR/requirements.txt"
mkdir -p "$APP_DIR/static"
install -m 644 "$ORIGEM/static/index.html" "$APP_DIR/static/index.html"

echo "==> Ambiente virtual"
[[ -d "$APP_DIR/.venv" ]] || python3 -m venv "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/pip" install --upgrade pip --quiet
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt" --quiet

echo "==> Ficheiro de ambiente"
if [[ ! -f "$ENV_FILE" ]]; then
  cat > "$ENV_FILE" <<'EOF'
# Chaves do Forex Advisor. Este ficheiro NUNCA chega ao browser.
ANTHROPIC_API_KEY=
FINNHUB_API_KEY=
ANTHROPIC_MODEL=claude-sonnet-5

# Onde ficam alertas e logs
FOREX_DATA_DIR=/var/lib/forex-advisor

# Travão de custos: análises ao Claude por IP, por hora
LIMITE_IA_HORA=40

# Segundos entre verificações de alertas
INTERVALO_ALERTAS=30

# Opcional: notificação de alertas por Telegram
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=
EOF
  echo "    criado $ENV_FILE — PREENCHE AS CHAVES antes de arrancar"
else
  echo "    $ENV_FILE já existe, mantido"
fi
chmod 600 "$ENV_FILE"
chown root:"$UTILIZADOR" "$ENV_FILE"

echo "==> Permissões"
chown -R root:root "$APP_DIR"
chown -R "$UTILIZADOR":"$UTILIZADOR" "$DATA_DIR"
chmod 750 "$DATA_DIR"

echo "==> systemd"
install -m 644 "$ORIGEM/deploy/forex-advisor.service" /etc/systemd/system/forex-advisor.service
systemctl daemon-reload
systemctl enable forex-advisor >/dev/null
systemctl restart forex-advisor

sleep 3
if systemctl is-active --quiet forex-advisor; then
  echo "==> Serviço a correr."
  curl -sf http://127.0.0.1:8100/api/saude && echo
else
  echo "==> O serviço NÃO arrancou. Vê:  journalctl -u forex-advisor -n 50 --no-pager" >&2
  exit 1
fi

cat <<'FIM'

──────────────────────────────────────────────────────────────
Falta ligar ao nginx:

  1) apt install -y apache2-utils
     htpasswd -c /etc/nginx/.htpasswd-advisor luis

  2) Cola o conteúdo de deploy/nginx-advisor.conf dentro do
     server{} de /etc/nginx/sites-available/otc-trade

  3) nginx -t && systemctl reload nginx

Fica em: https://luis-otc.duckdns.org/advisor/

Comandos úteis:
  systemctl restart forex-advisor
  journalctl -u forex-advisor -f
  tail -f /var/lib/forex-advisor/app.log
──────────────────────────────────────────────────────────────
FIM
