#!/usr/bin/env python3
"""
Liga o Forex Advisor ao nginx sem edição manual.

Instala o bloco em /etc/nginx/snippets/forex-advisor.conf e insere um
`include` no server{} que serve HTTPS. Faz backup, valida com `nginx -t`
e reverte sozinho se a configuração ficar inválida.

    python3 deploy/ligar_nginx.py [--site /etc/nginx/sites-available/otc-trade]
"""

from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

SNIPPET_DESTINO = Path("/etc/nginx/snippets/forex-advisor.conf")
LINHA_INCLUDE = "    include snippets/forex-advisor.conf;"
MARCA = "snippets/forex-advisor.conf"


def erro(mensagem: str) -> None:
    print(f"ERRO: {mensagem}", file=sys.stderr)
    sys.exit(1)


def encontrar_bloco_https(linhas: list[str]) -> tuple[int, int]:
    """Devolve (inicio, fim) do server{} que tem `listen 443`.

    Conta chavetas para não confundir blocos aninhados (location, if, ...).
    """
    for i, linha in enumerate(linhas):
        if not re.match(r"\s*server\s*\{", linha):
            continue
        profundidade = 0
        tem_443 = False
        for j in range(i, len(linhas)):
            sem_comentario = linhas[j].split("#", 1)[0]
            profundidade += sem_comentario.count("{") - sem_comentario.count("}")
            if re.search(r"\blisten\b[^;]*\b443\b", sem_comentario):
                tem_443 = True
            if profundidade == 0:
                if tem_443:
                    return i, j
                break
    return -1, -1


def ponto_de_insercao(linhas: list[str], inicio: int, fim: int) -> int:
    """A seguir ao último server_name do bloco; senão, logo após o `server {`."""
    for k in range(fim, inicio, -1):
        if re.match(r"\s*server_name\b", linhas[k]):
            return k + 1
    return inicio + 1


def correr(comando: list[str]) -> tuple[int, str]:
    processo = subprocess.run(comando, capture_output=True, text=True)
    return processo.returncode, (processo.stdout + processo.stderr).strip()


def main() -> None:
    analisador = argparse.ArgumentParser()
    analisador.add_argument("--site", default="/etc/nginx/sites-available/otc-trade")
    analisador.add_argument("--snippet", default="deploy/nginx-advisor.conf")
    analisador.add_argument("--dry-run", action="store_true")
    args = analisador.parse_args()

    site = Path(args.site)
    origem = Path(args.snippet)

    if not site.is_file():
        erro(f"site não encontrado: {site}\nIndica o correto com --site")
    if not origem.is_file():
        erro(f"snippet não encontrado: {origem}")

    # 1. instalar o snippet
    if not args.dry_run:
        SNIPPET_DESTINO.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(origem, SNIPPET_DESTINO)
        SNIPPET_DESTINO.chmod(0o644)
    print(f"snippet -> {SNIPPET_DESTINO}")

    texto = site.read_text(encoding="utf-8")
    if MARCA in texto:
        print("include já presente, nada a fazer.")
        return

    linhas = texto.splitlines(keepends=True)
    inicio, fim = encontrar_bloco_https(linhas)
    if inicio < 0:
        erro(
            f"não encontrei nenhum server{{}} com `listen 443` em {site}.\n"
            f"Acrescenta à mão:  {LINHA_INCLUDE.strip()}"
        )

    posicao = ponto_de_insercao(linhas, inicio, fim)
    linhas.insert(posicao, LINHA_INCLUDE + "\n")
    novo = "".join(linhas)

    if args.dry_run:
        print(f"[dry-run] inseria na linha {posicao + 1} de {site}:\n{LINHA_INCLUDE}")
        return

    # 2. backup antes de mexer
    backup = site.with_suffix(
        site.suffix + f".bak-{datetime.now():%Y%m%d-%H%M%S}"
    )
    shutil.copyfile(site, backup)
    site.write_text(novo, encoding="utf-8")
    print(f"include inserido na linha {posicao + 1} (backup: {backup})")

    # 3. validar e, se falhar, reverter
    codigo, saida = correr(["nginx", "-t"])
    if codigo != 0:
        shutil.copyfile(backup, site)
        erro(f"`nginx -t` falhou, alteração revertida:\n{saida}")
    print("nginx -t OK")

    codigo, saida = correr(["systemctl", "reload", "nginx"])
    if codigo != 0:
        shutil.copyfile(backup, site)
        correr(["systemctl", "reload", "nginx"])
        erro(f"reload falhou, alteração revertida:\n{saida}")
    print("nginx recarregado")


if __name__ == "__main__":
    main()
