"""
avaliar_sinais.py — Mede o que os sinais da IA teriam dado na prática.

Lê /var/lib/forex-advisor/sinais_ia.jsonl (escrito pelo motor.py a cada
pedido de sinal) e, para cada COMPRAR/VENDER, verifica em velas de 1 hora do
Yahoo se o preço tocou primeiro no take profit ou no stop loss. Se ambos
caírem na mesma vela, conta como stop (hipótese pessimista).

Compara também com o "score fixo" (regras RSI/EMA/MACD) nas mesmas ocasiões
e com o mesmo SL/TP de 1×/2× ATR, para saber se a IA acrescenta algo.

Uso:
    python avaliar_sinais.py [caminho/sinais_ia.jsonl]
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pandas as pd
import yfinance as yf

FICHEIRO = Path(sys.argv[1] if len(sys.argv) > 1 else
                Path(os.getenv("FOREX_DATA_DIR", "/var/lib/forex-advisor")) / "sinais_ia.jsonl")


def carregar() -> pd.DataFrame:
    linhas = [json.loads(l) for l in FICHEIRO.read_text(encoding="utf-8").splitlines() if l.strip()]
    df = pd.DataFrame(linhas)
    df["momento"] = pd.to_datetime(df["momento"], utc=True)
    # Pedidos repetidos na mesma vela contam uma vez só.
    return df.drop_duplicates(subset=["par", "timeframe", "vela"], keep="first")


_cache: dict[str, pd.DataFrame] = {}


def velas(ticker: str) -> pd.DataFrame:
    if ticker not in _cache:
        d = yf.download(ticker, period="730d", interval="1h", progress=False, auto_adjust=False)
        if isinstance(d.columns, pd.MultiIndex):
            d.columns = d.columns.get_level_values(0)
        d.index = d.index.tz_convert("UTC") if d.index.tz else d.index.tz_localize("UTC")
        _cache[ticker] = d
    return _cache[ticker]


def desfecho(ticker: str, desde: pd.Timestamp, direcao: int, sl: float, tp: float) -> str:
    d = velas(ticker)
    d = d[d.index > desde]
    for _, r in d.iterrows():
        bate_sl = r["Low"] <= sl if direcao > 0 else r["High"] >= sl
        bate_tp = r["High"] >= tp if direcao > 0 else r["Low"] <= tp
        if bate_sl:
            return "SL"
        if bate_tp:
            return "TP"
    return "ABERTO"


def main() -> None:
    df = carregar()
    print(f"{len(df)} pedidos únicos em {FICHEIRO}")
    print(df["sinal"].value_counts().to_string(), "\n")

    res = []
    for _, s in df.iterrows():
        ticker = s.get("ticker")
        if not ticker:
            continue
        preco, atr = float(s["preco"]), float(s["atr"])
        if s["sinal"] in ("COMPRAR", "VENDER"):
            d = 1 if s["sinal"] == "COMPRAR" else -1
            res.append({"fonte": "IA", "timeframe": s["timeframe"], "confianca": s["confianca"],
                        "desfecho": desfecho(ticker, s["momento"], d, s["stop_loss"], s["take_profit"]),
                        "rr": s["rr"]})
        score = float(s.get("score_fixo", 0))
        if abs(score) >= 2.5:
            d = 1 if score > 0 else -1
            res.append({"fonte": "score_fixo", "timeframe": s["timeframe"], "confianca": None,
                        "desfecho": desfecho(ticker, s["momento"], d, preco - d * atr, preco + d * 2 * atr),
                        "rr": 2.0})

    if not res:
        print("Ainda não há sinais COMPRAR/VENDER suficientes para avaliar.")
        return
    r = pd.DataFrame(res)
    fechados = r[r["desfecho"] != "ABERTO"].copy()
    fechados["R"] = fechados.apply(lambda x: x["rr"] if x["desfecho"] == "TP" else -1.0, axis=1)

    print("== Resultado por fonte (R = múltiplos do risco; >0 é lucro)")
    resumo = fechados.groupby("fonte").agg(
        trades=("R", "size"), acerto=("desfecho", lambda x: round((x == "TP").mean() * 100, 1)),
        R_total=("R", "sum"), R_medio=("R", "mean"))
    print(resumo.round(2).to_string())
    print(f"\nEm aberto: {(r['desfecho'] == 'ABERTO').sum()}")

    ia = fechados[fechados["fonte"] == "IA"]
    if len(ia) >= 5:
        print("\n== Calibração da IA (a taxa de acerto sobe com a confiança?)")
        ia = ia.assign(faixa=pd.cut(ia["confianca"].astype(float), [0, 64, 74, 100],
                                    labels=["60-64", "65-74", "75+"]))
        print(ia.groupby("faixa", observed=True).agg(
            trades=("R", "size"), acerto=("desfecho", lambda x: round((x == "TP").mean() * 100, 1)),
            R_medio=("R", "mean")).round(2).to_string())
    print("\nCom menos de ~50 trades fechados por fonte, as diferenças são quase de certeza ruído.")


if __name__ == "__main__":
    main()
