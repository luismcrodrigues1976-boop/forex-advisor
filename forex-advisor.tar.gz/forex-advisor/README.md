# Forex Advisor

Assistente de análise técnica de Forex: indicadores calculados a partir de
dados reais do Yahoo Finance, notícias e calendário económico da Finnhub, e
análise redigida pelo Claude. Corre como serviço web atrás do nginx.

> Isto não é aconselhamento financeiro. Os sinais são informativos.

## Funcionalidades

- **Sinal por par/timeframe** — RSI, EMA9/21, ATR e MACD, com stop loss a 1×ATR
  e take profit a 2×ATR, comentados pelo modelo.
- **Scanner** — pontua os 13 instrumentos de uma vez (RSI ±2, EMA ±1.5,
  MACD ±1; limiar 2.5) e mostra só os setups claros.
- **Sentimento de mercado** — notícias da Finnhub cruzadas com as variações
  semanais dos pares principais.
- **Calendário económico** — próximos 7 dias, filtrado por impacto.
- **Alertas de preço** — verificados no servidor, com o browser fechado, e
  opcionalmente notificados por Telegram.
- **Modo automático** — interruptor no painel do scanner. O servidor corre a
  confluência de timeframes de X em X minutos (sem gastar tokens), mostra os
  candidatos acima dos limiares e notifica os novos por Telegram, sem repetir o
  mesmo par e direção durante o período de arrefecimento. Pausa ao fim de
  semana e silencia-se se a conta prop estiver violada. Opcionalmente, cada
  candidato é confirmado pela IA antes de ser notificado (com SL, TP e lote),
  com um teto de análises por hora. Não abre posições.
- **Conta prop firm** — regras da avaliação (perda diária, perda máxima
  estática ou trailing, objetivo, dias mínimos), barras de consumo de cada
  limite, aviso por Telegram antes de violar e calculadora de lote que respeita
  o risco por trade e a margem que ainda sobra. O equity é introduzido à mão:
  nada disto se liga à corretora.

## Como a IA decide o sinal

1. O servidor monta o contexto: últimas 20 velas, indicadores, estrutura
   (máximo/mínimo em ATR), percentil do ATR, score fixo, confluência entre
   15m/1h/4h/Diário, notícias filtradas pelas moedas do par e eventos de
   impacto médio/alto nas próximas 24 h.
2. O Claude responde por uma ferramenta com esquema fixo (sinal, confiança
   0-100, SL, TP, invalidação, justificação) — nada de texto livre a adivinhar.
3. O código valida: SL entre 0,8 e 2,5 × ATR, R:R ≥ `RR_MINIMO`, confiança
   ≥ `CONFIANCA_MINIMA`, e bloqueio perto de eventos de impacto alto. Se falhar,
   o sinal passa a AGUARDAR e o ajuste aparece na análise.
4. Cada decisão fica em `sinais_ia.jsonl`; `python avaliar_sinais.py` mede a
   taxa de acerto real, a calibração da confiança e compara com o score fixo.
5. A mesma vela devolve a mesma resposta durante 5 minutos (cache), o que
   poupa chamadas e evita sinais contraditórios.

## Arquitetura

```
app.py              API FastAPI (rotas, limite de ritmo, ciclo de alertas)
motor.py            Mercado, indicadores, Finnhub, Claude, alertas
prop.py             Regras de prop firm, drawdown e tamanho de posição
auto.py             Modo automático (scan contínuo + notificação)
static/index.html   Frontend — um ficheiro, sem dependências externas
deploy/             systemd, nginx, scripts de instalação
```

As chaves de API vivem em `/etc/forex-advisor.env`, lido pelo systemd. Nunca
chegam ao browser e nunca entram no repositório.

## Instalar

```bash
git clone https://github.com/luismcrodrigues1976-boop/forex-advisor.git
cd forex-advisor
bash publicar.sh --so-servidor
nano /etc/forex-advisor.env      # ANTHROPIC_API_KEY, FINNHUB_API_KEY
systemctl restart forex-advisor
```

O script instala em `/opt/forex-advisor`, cria o serviço systemd, define a
palavra-passe de acesso e liga o bloco ao nginx (com backup e rollback
automático se a configuração ficar inválida).

Variáveis disponíveis: ver `exemplo.env`.

## API

| Método | Rota | Usa |
|---|---|---|
| GET | `/api/config` | — |
| GET | `/api/saude` | — |
| GET | `/api/scan` | Yahoo |
| GET | `/api/indicadores?par=EUR/USD&timeframe=1 hora` | Yahoo |
| POST | `/api/sinal` `{par, timeframe}` | Yahoo + Claude |
| POST | `/api/sentimento` | Yahoo + Finnhub + Claude |
| GET | `/api/calendario?dias=7` | Finnhub |
| GET/POST/DELETE | `/api/alertas` | Yahoo |
| GET/PUT | `/api/auto` | Yahoo (+ Claude se `confirmar_ia`) |
| GET | `/api/conta` | — |
| PUT | `/api/conta/regras` | — |
| POST | `/api/conta/equity` `{equity, operou}` | — |
| POST | `/api/conta/lote` `{par, entrada, stop}` | Yahoo (conversão cambial) |

`/api/indicadores` devolve os indicadores sem chamar o modelo — útil para
integrar noutros serviços sem gastar tokens.

## Segurança

- Acesso protegido por `auth_basic` no nginx.
- Limite de análises ao modelo por IP e por hora (`LIMITE_IA_HORA`, por
  omissão 40). Scan e indicadores não contam.
- Serviço corre como utilizador `forex` com `ProtectSystem=strict`; só
  `/var/lib/forex-advisor` é gravável.
- `.gitignore` bloqueia `.env`, logs e dados de execução; o script de
  publicação aborta se algum `.env` chegar à área de staging.

## Testes

```bash
python3 teste_api.py      # 21 testes: rotas, validação, limite, alertas
python3 teste_prop.py     # 25 testes: regras, reset diário, trailing, lote
python3 teste_auto.py     # 20 testes: limiares, arrefecimento, IA, fim de semana
python3 teste_nginx.py    #  7 testes: deteção do bloco server{} HTTPS
```

Nenhum toca na rede — Yahoo, Finnhub e Claude são substituídos por duplos.

## Notas

`--workers 1` no systemd é deliberado: a cache de cotações e o ciclo de
alertas vivem no processo, e com vários workers os alertas disparariam uma vez
por worker.
