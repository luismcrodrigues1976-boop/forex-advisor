# Forex Advisor

Assistente de análise técnica de Forex: indicadores calculados a partir de
dados reais do Yahoo Finance, notícias e calendário económico da Finnhub, e
análise redigida pelo Claude. Corre como serviço web atrás do nginx.

> Isto não é aconselhamento financeiro. Os sinais são informativos.

## Funcionalidades

- **Sinal por par/timeframe** — RSI, EMA9/21, ATR e MACD, com stop loss a 1×ATR
  e take profit a 2×ATR, comentados pelo modelo.
- **Scanner** — pontua os 13 instrumentos de uma vez (RSI ±2, EMA ±1.5,
  MACD ±1; limiar 2.5) e mostra só os setups claros.
- **Sentimento de mercado** — notícias da Finnhub cruzadas com as variações
  semanais dos pares principais.
- **Calendário económico** — próximos 7 dias, filtrado por impacto.
- **Alertas de preço** — verificados no servidor, com o browser fechado, e
  opcionalmente notificados por Telegram.

## Arquitetura

```
app.py              API FastAPI (rotas, limite de ritmo, ciclo de alertas)
motor.py            Mercado, indicadores, Finnhub, Claude, alertas
static/index.html   Frontend — um ficheiro, sem dependências externas
deploy/             systemd, nginx, scripts de instalação
```

As chaves de API vivem em `/etc/forex-advisor.env`, lido pelo systemd. Nunca
chegam ao browser e nunca entram no repositório.

## Instalar

```bash
git clone https://github.com/luismcrodrigues1976-boop/forex-advisor.git
cd forex-advisor
bash publicar.sh --so-servidor
nano /etc/forex-advisor.env      # ANTHROPIC_API_KEY, FINNHUB_API_KEY
systemctl restart forex-advisor
```

O script instala em `/opt/forex-advisor`, cria o serviço systemd, define a
palavra-passe de acesso e liga o bloco ao nginx (com backup e rollback
automático se a configuração ficar inválida).

Variáveis disponíveis: ver `exemplo.env`.

## API

| Método | Rota | Usa |
|---|---|---|
| GET | `/api/config` | — |
| GET | `/api/saude` | — |
| GET | `/api/scan` | Yahoo |
| GET | `/api/indicadores?par=EUR/USD&timeframe=1 hora` | Yahoo |
| POST | `/api/sinal` `{par, timeframe}` | Yahoo + Claude |
| POST | `/api/sentimento` | Yahoo + Finnhub + Claude |
| GET | `/api/calendario?dias=7` | Finnhub |
| GET/POST/DELETE | `/api/alertas` | Yahoo |

`/api/indicadores` devolve os indicadores sem chamar o modelo — útil para
integrar noutros serviços sem gastar tokens.

## Segurança

- Acesso protegido por `auth_basic` no nginx.
- Limite de análises ao modelo por IP e por hora (`LIMITE_IA_HORA`, por
  omissão 40). Scan e indicadores não contam.
- Serviço corre como utilizador `forex` com `ProtectSystem=strict`; só
  `/var/lib/forex-advisor` é gravável.
- `.gitignore` bloqueia `.env`, logs e dados de execução; o script de
  publicação aborta se algum `.env` chegar à área de staging.

## Testes

```bash
python3 teste_api.py      # 15 testes: rotas, validação, limite, alertas
python3 teste_nginx.py    #  7 testes: deteção do bloco server{} HTTPS
```

Nenhum toca na rede — Yahoo, Finnhub e Claude são substituídos por duplos.

## Notas

`--workers 1` no systemd é deliberado: a cache de cotações e o ciclo de
alertas vivem no processo, e com vários workers os alertas disparariam uma vez
por worker.
