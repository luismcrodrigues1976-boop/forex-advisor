"""Testa a deteção do bloco server{} HTTPS, sem tocar no nginx real."""
import importlib.util
import unittest
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "ligar_nginx", Path(__file__).parent / "deploy" / "ligar_nginx.py"
)
ln = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ln)


def linhas(texto: str) -> list[str]:
    return texto.splitlines(keepends=True)


CONFIG_REAL = """\
server {
    listen 80;
    server_name luis-otc.duckdns.org;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name luis-otc.duckdns.org;

    location /forex/ {
        alias /var/www/forex/;
    }

    location / {
        proxy_pass http://127.0.0.1:3000;
    }
}
"""


class TesteDetecao(unittest.TestCase):
    def test_escolhe_o_bloco_443_e_nao_o_80(self):
        ls = linhas(CONFIG_REAL)
        inicio, fim = ln.encontrar_bloco_https(ls)
        self.assertIn("443", ls[inicio + 1])
        self.assertEqual(ls[fim].strip(), "}")

    def test_insere_depois_do_server_name(self):
        ls = linhas(CONFIG_REAL)
        inicio, fim = ln.encontrar_bloco_https(ls)
        pos = ln.ponto_de_insercao(ls, inicio, fim)
        self.assertIn("server_name", ls[pos - 1])

    def test_chavetas_aninhadas_nao_fecham_o_bloco_cedo(self):
        """Os location{} não podem ser confundidos com o fim do server{}."""
        ls = linhas(CONFIG_REAL)
        inicio, fim = ln.encontrar_bloco_https(ls)
        self.assertGreater(fim - inicio, 10)  # apanhou o bloco inteiro

    def test_sem_bloco_443(self):
        ls = linhas("server {\n  listen 80;\n  server_name x;\n}\n")
        self.assertEqual(ln.encontrar_bloco_https(ls), (-1, -1))

    def test_listen_comentado_e_ignorado(self):
        ls = linhas("server {\n  # listen 443 ssl;\n  listen 8080;\n}\n")
        self.assertEqual(ln.encontrar_bloco_https(ls), (-1, -1))

    def test_ipv6_e_reconhecido(self):
        ls = linhas("server {\n  listen [::]:443 ssl;\n  server_name x;\n}\n")
        inicio, _ = ln.encontrar_bloco_https(ls)
        self.assertEqual(inicio, 0)

    def test_sem_server_name_cai_para_logo_apos_a_chaveta(self):
        ls = linhas("server {\n  listen 443 ssl;\n  root /var/www;\n}\n")
        inicio, fim = ln.encontrar_bloco_https(ls)
        self.assertEqual(ln.ponto_de_insercao(ls, inicio, fim), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
