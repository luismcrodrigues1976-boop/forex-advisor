"""Testa a API sem tocar na rede: o yfinance, a Finnhub e o Claude são
substituídos por duplos de teste."""
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

os.environ.setdefault("FOREX_DATA_DIR", tempfile.mkdtemp(prefix="forex-teste-"))
os.environ["ANTHROPIC_API_KEY"] = "teste"
os.environ["FINNHUB_API_KEY"] = "teste"

from fastapi.testclient import TestClient  # noqa: E402

import motor  # noqa: E402
import app as api_app  # noqa: E402


def velas(n=300, inicio=1.10, freq="1h"):
    idx = pd.date_range("2026-01-01", periods=n, freq=freq, tz="UTC")
    rng = np.random.default_rng(11)
    fecho = inicio + np.cumsum(rng.normal(0, 0.0008, n))
    return pd.DataFrame(
        {"Open": fecho, "High": fecho + 0.0006, "Low": fecho - 0.0006,
         "Close": fecho, "Volume": 1000.0},
        index=idx,
    )


class TesteAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cliente = TestClient(api_app.app)
        motor.alertas.ficheiro = Path(os.environ["FOREX_DATA_DIR"]) / "alertas.json"

    def setUp(self):
        motor.mercado._cache.clear()
        api_app._registos.clear()
        motor.alertas._alertas.clear()

    # --- fingir o download do Yahoo ---
    def fingir_mercado(self):
        def descarregar(tickers, periodo, intervalo):
            return {t: velas() for t in tickers}
        return patch.object(motor.Mercado, "_descarregar", side_effect=descarregar, autospec=False)

    def test_config(self):
        r = self.cliente.get("/api/config")
        self.assertEqual(r.status_code, 200)
        self.assertIn("EUR/USD", r.json()["pares"])
        self.assertIn("4 horas", r.json()["timeframes"])

    def test_scan(self):
        with self.fingir_mercado():
            r = self.cliente.get("/api/scan")
        self.assertEqual(r.status_code, 200)
        dados = r.json()
        self.assertEqual(dados["total"], len(motor.PARES))
        # ordenado por score decrescente
        scores = [x["score"] for x in dados["resultados"]]
        self.assertEqual(scores, sorted(scores, reverse=True))
        for linha in dados["resultados"]:
            self.assertIn(linha["sinal"], ("COMPRA", "VENDA", "NEUTRO"))

    def test_scan_sem_dados_devolve_503(self):
        with patch.object(motor.Mercado, "_descarregar", return_value={}):
            r = self.cliente.get("/api/scan")
        self.assertEqual(r.status_code, 503)

    def test_indicadores_nao_chamam_o_claude(self):
        with self.fingir_mercado(), patch.object(motor.Claude, "perguntar") as falso:
            r = self.cliente.get("/api/indicadores", params={"par": "EUR/USD", "timeframe": "4 horas"})
        self.assertEqual(r.status_code, 200)
        falso.assert_not_called()
        d = r.json()
        for chave in ("rsi", "ema9", "ema21", "atr", "macd_hist", "stop_loss", "take_profit"):
            self.assertIn(chave, d)
        self.assertAlmostEqual(d["take_profit"], d["atr"] * 2)
        self.assertTrue(d["velas"])

    def test_par_invalido(self):
        r = self.cliente.get("/api/indicadores", params={"par": "XPTO/USD"})
        self.assertEqual(r.status_code, 400)

    def test_sinal(self):
        with self.fingir_mercado(), \
             patch.object(motor.Claude, "perguntar", return_value="🎯 SINAL: AGUARDAR"), \
             patch.object(motor.Finnhub, "noticias", return_value=["Fed mantém taxas"]):
            r = self.cliente.post("/api/sinal", json={"par": "EUR/USD", "timeframe": "1 hora"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["analise"], "🎯 SINAL: AGUARDAR")
        self.assertEqual(r.json()["noticias"], ["Fed mantém taxas"])

    def test_sentimento(self):
        with self.fingir_mercado(), \
             patch.object(motor.Claude, "perguntar", return_value="🌍 Risk-On"), \
             patch.object(motor.Finnhub, "noticias", return_value=[]):
            r = self.cliente.post("/api/sentimento")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(len(r.json()["variacoes"]), len(motor.PARES_SENTIMENTO))

    def test_limite_de_ritmo(self):
        original = api_app.LIMITE_IA
        api_app.LIMITE_IA = 2
        try:
            with self.fingir_mercado(), \
                 patch.object(motor.Claude, "perguntar", return_value="ok"), \
                 patch.object(motor.Finnhub, "noticias", return_value=[]):
                corpo = {"par": "EUR/USD", "timeframe": "1 hora"}
                self.assertEqual(self.cliente.post("/api/sinal", json=corpo).status_code, 200)
                self.assertEqual(self.cliente.post("/api/sinal", json=corpo).status_code, 200)
                terceiro = self.cliente.post("/api/sinal", json=corpo)
                self.assertEqual(terceiro.status_code, 429)
        finally:
            api_app.LIMITE_IA = original

    def test_limite_nao_afeta_endpoints_gratuitos(self):
        api_app.LIMITE_IA = 0
        try:
            with self.fingir_mercado():
                self.assertEqual(self.cliente.get("/api/scan").status_code, 200)
        finally:
            api_app.LIMITE_IA = int(os.getenv("LIMITE_IA_HORA", "40"))

    def test_ciclo_de_vida_dos_alertas(self):
        r = self.cliente.post("/api/alertas",
                              json={"par": "EUR/USD", "condicao": "Acima de", "preco": 1.10})
        self.assertEqual(r.status_code, 200)
        id_alerta = r.json()["id"]

        self.assertEqual(len(self.cliente.get("/api/alertas").json()["alertas"]), 1)

        self.assertEqual(self.cliente.delete(f"/api/alertas/{id_alerta}").status_code, 200)
        self.assertEqual(self.cliente.delete(f"/api/alertas/{id_alerta}").status_code, 404)

    def test_alerta_invalido(self):
        for corpo in (
            {"par": "XPTO", "condicao": "Acima de", "preco": 1.1},
            {"par": "EUR/USD", "condicao": "Talvez", "preco": 1.1},
            {"par": "EUR/USD", "condicao": "Acima de", "preco": -1},
        ):
            r = self.cliente.post("/api/alertas", json=corpo)
            self.assertIn(r.status_code, (400, 422), corpo)

    def test_alerta_dispara_e_notifica(self):
        self.cliente.post("/api/alertas",
                          json={"par": "EUR/USD", "condicao": "Abaixo de", "preco": 5.0})
        with patch.object(motor.Mercado, "precos_atuais", return_value={"EURUSD=X": 1.05}), \
             patch.object(motor, "notificar_telegram", return_value=True) as tele:
            disparados = motor.verificar_alertas()
        self.assertEqual(len(disparados), 1)
        self.assertEqual(disparados[0]["preco_disparo"], 1.05)
        tele.assert_called_once()
        # não volta a disparar
        with patch.object(motor.Mercado, "precos_atuais", return_value={"EURUSD=X": 1.05}):
            self.assertEqual(motor.verificar_alertas(), [])

    def test_calendario_sem_chave(self):
        with patch.dict(os.environ, {"FINNHUB_API_KEY": ""}):
            r = self.cliente.get("/api/calendario")
        self.assertEqual(r.status_code, 503)

    def test_calendario_classifica_impacto(self):
        eventos = [
            {"time": "2026-09-20T12:30:00", "country": "US", "event": "NFP",
             "impact": "high", "prev": 1, "estimate": 2, "actual": 3},
            {"time": "2026-09-19T09:00:00", "country": "EU", "event": "PMI", "impact": "2"},
        ]
        with patch.object(motor.Finnhub, "calendario", return_value=eventos):
            r = self.cliente.get("/api/calendario?dias=7")
        self.assertEqual(r.status_code, 200)
        saida = r.json()["eventos"]
        self.assertEqual(saida[0]["quando"], "2026-09-19 09:00")  # ordenado por data
        self.assertEqual({e["impacto"] for e in saida}, {"alto", "medio"})

    def test_frontend_servido(self):
        r = self.cliente.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn("Forex Advisor", r.text)


    # --- melhor oportunidade (confluência) ---
    def test_melhor_devolve_ranking_ordenado(self):
        with self.fingir_mercado():
            r = self.cliente.get("/api/melhor")
        self.assertEqual(r.status_code, 200)
        d = r.json()
        self.assertIsNotNone(d["melhor"])
        forcas = [c["forca"] for c in d["ranking"]]
        self.assertEqual(forcas, sorted(forcas, reverse=True))
        self.assertEqual(d["melhor"], d["ranking"][0])

    def test_melhor_traz_timeframe_ideal_valido(self):
        with self.fingir_mercado():
            d = self.cliente.get("/api/melhor").json()
        for c in d["ranking"]:
            self.assertIn(c["timeframe_ideal"], motor.TIMEFRAMES)
            self.assertIn(c["timeframe_ideal"], c["detalhe"])

    def test_melhor_timeframe_ideal_concorda_com_a_direcao(self):
        """O timeframe escolhido tem de apontar para o mesmo lado do sinal."""
        with self.fingir_mercado():
            d = self.cliente.get("/api/melhor").json()
        for c in d["ranking"]:
            concordantes = [
                tf for tf, e in c["detalhe"].items()
                if (e["score"] > 0) == (c["direcao"] == "COMPRA")
            ]
            if concordantes:
                self.assertIn(c["timeframe_ideal"], concordantes, c["par"])

    def test_melhor_nao_chama_o_modelo(self):
        with self.fingir_mercado(), patch.object(motor.Claude, "perguntar") as falso:
            r = self.cliente.get("/api/melhor")
        self.assertEqual(r.status_code, 200)
        falso.assert_not_called()

    def test_melhor_sem_dados_da_503(self):
        with patch.object(motor.Mercado, "_descarregar", return_value={}):
            r = self.cliente.get("/api/melhor")
        self.assertEqual(r.status_code, 503)

    def test_par_parado_e_penalizado(self):
        """ATR quase nulo corta a força a metade e marca o par como parado."""
        def sem_movimento(tickers, periodo, intervalo):
            df = velas().copy()
            # Preço praticamente imóvel: o ATR inclui o salto entre fechos,
            # por isso não basta achatar o High/Low.
            df["Close"] = 1.10 + (df.index.astype("int64") % 3) * 1e-7
            df["Open"] = df["Close"]
            df["High"] = df["Close"] + 1e-7
            df["Low"] = df["Close"] - 1e-7
            return {t: df for t in tickers}
        with patch.object(motor.Mercado, "_descarregar", side_effect=sem_movimento):
            d = self.cliente.get("/api/melhor").json()
        self.assertTrue(all(c["parado"] for c in d["ranking"]))



if __name__ == "__main__":
    unittest.main(verbosity=2)
