"""
API web do Forex Advisor.

Corre atrás do nginx, em 127.0.0.1:8100. As chaves ficam sempre no servidor —
o browser nunca as vê. Proteção de acesso é feita pelo nginx (auth_basic);
aqui há apenas um limitador de ritmo para travar gastos na API da Anthropic.
"""

from __future__ import annotations

import asyncio
import os
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

import motor

motor.configurar_log()

DIR_ESTATICO = Path(__file__).resolve().parent / "static"
INTERVALO_ALERTAS = int(os.getenv("INTERVALO_ALERTAS", "30"))

# ──────────────────────────────────────────────────────────────────────
# Limitador de ritmo (protege a carteira)
# ──────────────────────────────────────────────────────────────────────

LIMITE_IA = int(os.getenv("LIMITE_IA_HORA", "40"))  # pedidos ao Claude por IP/hora
_registos: dict[str, deque] = defaultdict(deque)


def limitar(request: Request) -> None:
    ip = request.headers.get("x-forwarded-for", request.client.host if request.client else "?")
    ip = ip.split(",")[0].strip()
    agora = time.time()
    janela = _registos[ip]
    while janela and agora - janela[0] > 3600:
        janela.popleft()
    if len(janela) >= LIMITE_IA:
        raise HTTPException(
            status_code=429,
            detail=f"Limite de {LIMITE_IA} análises por hora atingido. Tenta mais tarde.",
        )
    janela.append(agora)


# ──────────────────────────────────────────────────────────────────────
# Ciclo de vida
# ──────────────────────────────────────────────────────────────────────


async def ciclo_alertas() -> None:
    while True:
        try:
            disparados = await asyncio.to_thread(motor.verificar_alertas)
            for a in disparados:
                motor.log.info("Alerta disparado: %s @ %s", a["par"], a["preco_disparo"])
        except asyncio.CancelledError:
            raise
        except Exception:
            motor.log.exception("Erro no ciclo de alertas")
        await asyncio.sleep(INTERVALO_ALERTAS)


@asynccontextmanager
async def lifespan(app: FastAPI):
    tarefa = asyncio.create_task(ciclo_alertas())
    motor.log.info("API iniciada")
    yield
    tarefa.cancel()
    try:
        await tarefa
    except asyncio.CancelledError:
        pass


app = FastAPI(title="Forex Advisor", docs_url=None, redoc_url=None, lifespan=lifespan)


@app.exception_handler(RuntimeError)
async def erro_runtime(request: Request, exc: RuntimeError):
    return JSONResponse(status_code=503, content={"detail": str(exc)})


# ──────────────────────────────────────────────────────────────────────
# Endpoints
# ──────────────────────────────────────────────────────────────────────


class PedidoSinal(BaseModel):
    par: str
    timeframe: str = "1 hora"


class PedidoAlerta(BaseModel):
    par: str
    condicao: str
    preco: float = Field(gt=0)


@app.get("/api/config")
async def api_config():
    return motor.config()


@app.get("/api/saude")
async def api_saude():
    return {"ok": True, "alertas_ativos": len(motor.alertas.listar())}


@app.get("/api/scan")
async def api_scan():
    try:
        return await asyncio.to_thread(motor.scan)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.get("/api/melhor")
async def api_melhor():
    """Cruza todos os pares com vários timeframes. Não chama o modelo."""
    try:
        return await asyncio.to_thread(motor.melhor)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.get("/api/indicadores")
async def api_indicadores(par: str, timeframe: str = "1 hora"):
    """Indicadores sem chamar o Claude — não conta para o limite."""
    try:
        return await asyncio.to_thread(motor.indicadores_do_par, par, timeframe)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.post("/api/sinal")
async def api_sinal(pedido: PedidoSinal, request: Request):
    limitar(request)
    try:
        return await asyncio.to_thread(motor.sinal, pedido.par, pedido.timeframe)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.post("/api/sentimento")
async def api_sentimento(request: Request):
    limitar(request)
    try:
        return await asyncio.to_thread(motor.sentimento)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.get("/api/calendario")
async def api_calendario(dias: int = 7):
    dias = max(1, min(dias, 30))
    try:
        return await asyncio.to_thread(motor.calendario, dias)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Calendário indisponível ({exc}). No plano gratuito da Finnhub "
                   "este endpoint costuma estar reservado a subscrições pagas.",
        )


@app.get("/api/alertas")
async def api_listar_alertas():
    return {"alertas": motor.alertas.listar(apenas_ativos=False)}


@app.post("/api/alertas")
async def api_criar_alerta(pedido: PedidoAlerta):
    try:
        return motor.alertas.adicionar(pedido.par, pedido.condicao, pedido.preco)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.delete("/api/alertas/{id_alerta}")
async def api_apagar_alerta(id_alerta: int):
    if not motor.alertas.remover(id_alerta):
        raise HTTPException(status_code=404, detail="Alerta não encontrado.")
    return {"removido": id_alerta}


# ──────────────────────────────────────────────────────────────────────
# Frontend
# ──────────────────────────────────────────────────────────────────────

if DIR_ESTATICO.is_dir():
    app.mount("/static", StaticFiles(directory=DIR_ESTATICO), name="static")

    @app.get("/")
    async def raiz():
        return FileResponse(DIR_ESTATICO / "index.html")
